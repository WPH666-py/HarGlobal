/**
 * dsh-clashvpn — the bundled mihomo core, started and reported by the Host.
 *
 * The core is a plain proxy engine: it reads a Clash configuration from the data directory and
 * exposes `external-controller` on loopback, on by default, so the settings card and any future
 * node switcher talk to it over HTTP instead of guessing. Everything here is optional at runtime:
 * a build without the core binary reports `installed: false` and the rest of the Host is unaffected.
 */
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { applySubscription, ensureConfig, coreVersion, killCore, listNodes, listProxies, pidAlive, resolveBinary, resolveSelectorGroup, selectNode, startCore } from './lib/mihomo.js'


/**
 * Remember the subscription the user typed in Settings.
 *
 * The row configuration stays the deployment default; this file is the per-machine choice, so a
export const name = 'dsh-clashvpn'

/** Host of a subscription URL, for status without echoing its token. */
function hostOf(url) {
  try { return new URL(url).host } catch { return '' }
}

/**
 * The node a url-test group currently uses.
 * @param controllerPort - controller port on loopback.
 * @param group - group name.
 * @returns the node name, or an empty string when the controller cannot say.
 */
async function selectedNode(controllerPort, group) {
  try {
    const response = await fetch(`http://127.0.0.1:${String(controllerPort)}/proxies/${encodeURIComponent(group)}`, { signal: AbortSignal.timeout(1500) })
    if (!response.ok) return ''
    const body = await response.json()
    return typeof body?.now === 'string' ? body.now : ''
  } catch { return '' }
}

/**
 * Product data directory this plugin keeps its configuration under.
 *
 * The Host runs under the runtime node the installer staged, so `<install>/data` is two levels
 * above that interpreter; `DSH_HOME` overrides it when the launcher sets one.
 * @returns the absolute data directory.
 */
function resolveHome() {
  if (typeof process.env.DSH_HOME === 'string' && process.env.DSH_HOME.trim() !== '') return process.env.DSH_HOME
  return join(dirname(process.execPath), '..', '..', '..', 'data')
}

/**
 * Normalise the row config.
 * @param raw - configured values, all optional.
 * @param home - product home directory.
 * @returns the settings this plugin runs with.
 */
function resolveConfig(raw, home) {
  const source = raw !== null && typeof raw === 'object' ? raw : {}
  return {
    enabled: source.enabled !== false,
    binary: typeof source.binary === 'string' ? source.binary : '',
    dataDir: typeof source.dataDir === 'string' && source.dataDir.trim() !== '' ? source.dataDir : home + '/clashvpn',
    mixedPort: Number.isInteger(source.mixedPort) ? source.mixedPort : 7898,
    controllerPort: Number.isInteger(source.controllerPort) ? source.controllerPort : 9098,
    autostart: source.autostart === true,
    subscription: {
      url: typeof source.subscription?.url === 'string' ? source.subscription.url : '',
      intervalSeconds: Number.isInteger(source.subscription?.intervalSeconds) ? source.subscription.intervalSeconds : 3600,
      groupName: typeof source.subscription?.groupName === 'string' && source.subscription.groupName.trim() !== '' ? source.subscription.groupName : 'AUTO',
    },
  }
}

/**
 * Mount the core and its routes.
 * @param ctx - plugin context.
 * @param rawConfig - row configuration.
 */
export function apply(ctx, rawConfig) {
  const home = resolveHome()
  const config = resolveConfig(rawConfig, home)
  if (!config.enabled) return
  const state = { pid: 0, lastError: '' }

  /**
   * Remember the subscription the user typed in Settings, so a user can subscribe without
   * editing cordis.patch.yml.
   * @param url - subscription address, empty to clear it.
   * @returns a short status line.
   */
  function saveSubscription(url) {
    try {
      mkdirSync(config.dataDir, { recursive: true })
      writeFileSync(config.dataDir + '/settings.json', JSON.stringify({ subscriptionUrl: url }))
      return url === '' ? 'cleared' : 'saved'
    } catch (error) {
      return error instanceof Error ? error.message : String(error)
    }
  }

  /**
   * Subscription the machine decided on, falling back to the row configuration.
   * @returns the URL, or an empty string.
   */
  function savedSubscription() {
    try {
      const body = JSON.parse(readFileSync(config.dataDir + '/settings.json', 'utf8'))
      return typeof body?.subscriptionUrl === 'string' ? body.subscriptionUrl : ''
    } catch {
      return ''
    }
  }

  /** Subscription the core should be running with. */
  function effectiveUrl() {
    const saved = savedSubscription()
    return saved !== '' ? saved : config.subscription.url
  }

  /**
   * Whether the configuration on disk predates the subscription the user chose.
   *
   * A saved subscription is applied on the next start: this answers whether that start has to
   * rewrite the file, which is what makes a save take effect without a manual restart.
   * @param url - subscription the core should use.
   * @returns true when the file must be regenerated.
   */
  function configIsStale(url) {
    if (url === '') return false
    try {
      return !readFileSync(config.dataDir + '/config.yaml', 'utf8').includes(url)
    } catch {
      return true
    }
  }

  /**
   * Whether the configuration on disk predates the selector group.
   *
   * The generated provider form used to name a `url-test` group, which ranks servers itself and
   * overwrites a manual pick on the next health check. Only that generated file is upgraded: a
   * complete configuration a provider supplied may legitimately contain its own url-test groups.
   * @returns true when the file must be regenerated with a selector.
   */
  function configNeedsSelector() {
    try {
      const text = readFileSync(config.dataDir + '/config.yaml', 'utf8')
      return text.includes('path: ./providers/sub.yaml') && !text.includes('type: select')
    } catch {
      return false
    }
  }

  /**
   * Whether this subscription was applied a moment ago.
   *
   * Applying costs one download of the whole subscription — seconds on a slow provider — while the
   * core keeps the provider refreshed on its own interval. A recent apply for the same address is
   * therefore reused; a saved address still applies immediately because it differs.
   * @param url - subscription the core should use.
   * @returns true when the file already reflects this address.
   */
  function recentlyApplied(url) {
    try {
      const record = JSON.parse(readFileSync(config.dataDir + '/applied.json', 'utf8'))
      return record?.url === url && typeof record?.at === 'number' && Date.now() - record.at < 6 * 60 * 60 * 1000
    } catch {
      return false
    }
  }

  /** Remember which subscription the configuration file was built from. */
  function rememberApplied(url) {
    try {
      writeFileSync(config.dataDir + '/applied.json', JSON.stringify({ url, at: Date.now() }))
    } catch (error) {
      void error
    }
  }

  /** Resolve the core and its configuration, or explain why not. */
  async function prepared() {
    const binary = resolveBinary(config.binary)
    if (binary === undefined) return { error: 'mihomo core not found next to the application' }
    try {
      const url = effectiveUrl()
      const upgrade = configNeedsSelector()
      const applied = url !== '' && (upgrade || !recentlyApplied(url))
        ? await applySubscription({ dataDir: config.dataDir, mixedPort: config.mixedPort, controllerPort: config.controllerPort }, url)
        : false
      if (applied) rememberApplied(url)
      const configPath = ensureConfig({
        dataDir: config.dataDir,
        mixedPort: config.mixedPort,
        controllerPort: config.controllerPort,
        subscription: { ...config.subscription, url: effectiveUrl() },
        overwrite: applied ? false : configIsStale(url) || upgrade,
      })
      return { binary, configPath }
    } catch (error) {
      return { error: error instanceof Error ? error.message : String(error) }
    }
  }

  async function reload() {
    stop()
    state.forcedWrite = true
    const result = await start()
    state.forcedWrite = false
    return result
  }

  async function start() {
    if (state.pid !== 0 && pidAlive(state.pid)) return 'already running'
    const ready = await prepared()
    if (ready.error !== undefined) { state.lastError = ready.error; return ready.error }
    const started = startCore({ binary: ready.binary, dataDir: config.dataDir, configPath: ready.configPath })
    if (started.error !== undefined) { state.lastError = started.error; return started.error }
    state.pid = started.child.pid ?? 0
    state.lastError = ''
    return 'started'
  }

  /** Stop the core. @returns a short status line. */
  function stop() {
    if (state.pid === 0) return 'not running'
    killCore(state.pid)
    state.pid = 0
    return 'stopped'
  }

  /** One observation for the status route. */
  async function observation() {
    const binary = resolveBinary(config.binary)
    const version = await coreVersion(config.controllerPort)
    const proxies = version === undefined ? undefined : await listProxies(config.controllerPort)
    return {
      installed: binary !== undefined,
      binary: binary ?? '',
      running: version !== undefined || (state.pid !== 0 && pidAlive(state.pid)),
      pid: state.pid,
      version: version ?? '',
      mixedPort: config.mixedPort,
      controller: 'http://127.0.0.1:' + String(config.controllerPort),
      proxies: proxies === undefined ? 0 : Object.keys(proxies).length,
      configPath: config.dataDir + '/config.yaml',
      subscription: config.subscription.url === '' ? { configured: false } : {
        configured: true,
        host: hostOf(config.subscription.url),
        group: config.subscription.groupName,
        node: await selectedNode(config.controllerPort, config.subscription.groupName),
      },
      lastError: state.lastError,
    }
  }

  /** Register the loopback routes; a Host without a web server keeps the plugin idle. */
  function registerRoutes() {
    ctx.inject(['webServer'], (web) => {
      web.effect(() => web.webServer.register({
        kind: 'exact',
        path: '/dsh-clashvpn/status',
        handler: async (request, response) => {
          if (request.method !== 'GET' && request.method !== 'HEAD') {
            response.writeHead(405, { allow: 'GET, HEAD' }).end()
            return
          }
          const body = JSON.stringify(await observation())
          response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(request.method === 'HEAD' ? undefined : body)
        },
      }), 'dsh-clashvpn: status route')
      web.effect(() => web.webServer.register({
        kind: 'exact',
        path: '/dsh-clashvpn/control',
        handler: async (request, response) => {
          if (request.method !== 'POST') {
            response.writeHead(405, { allow: 'POST' }).end()
            return
          }
          const url = new URL(request.url ?? '/', 'http://clashvpn.invalid')
          const action = url.searchParams.get('action')
          const result = action === 'start' ? await start() : action === 'reload' ? await reload() : action === 'stop' ? stop() : 'unknown action'
          response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(JSON.stringify({ result, status: await observation() }))
        },
      }), 'dsh-clashvpn: control route')
      web.effect(() => web.webServer.register({
        kind: 'exact',
        path: '/dsh-clashvpn/nodes',
        handler: async (request, response) => {
          if (request.method !== 'GET' && request.method !== 'HEAD') {
            response.writeHead(405, { allow: 'GET, HEAD' }).end()
            return
          }
          const probe = new URL(request.url ?? '/', 'http://clashvpn.invalid').searchParams.get('probe') === '1'
          const nodes = await listNodes(config.controllerPort, { probe })
          const body = JSON.stringify({ running: nodes !== undefined, nodes: nodes ?? [] })
          response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(request.method === 'HEAD' ? undefined : body)
        },
      }), 'dsh-clashvpn: nodes route')
      web.effect(() => web.webServer.register({
        kind: 'exact',
        path: '/dsh-clashvpn/select',
        handler: async (request, response) => {
          if (request.method !== 'POST') {
            response.writeHead(405, { allow: 'POST' }).end()
            return
          }
          const url = new URL(request.url ?? '/', 'http://clashvpn.invalid')
          const name = url.searchParams.get('name') ?? ''
          const preferred = url.searchParams.get('group') ?? config.subscription.groupName
          const group = name === '' ? preferred : await resolveSelectorGroup(config.controllerPort, name, preferred)
          const ok = name === '' ? false : await selectNode(config.controllerPort, group, name)
          response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(JSON.stringify({ selected: ok, group, name }))
        },
      }), 'dsh-clashvpn: select route')
      web.effect(() => web.webServer.register({
        kind: 'exact',
        path: '/dsh-clashvpn/config',
        handler: async (request, response) => {
          if (request.method !== 'POST') {
            response.writeHead(405, { allow: 'POST' }).end()
            return
          }
          let raw = ''
          for await (const chunk of request) raw += String(chunk)
          let url = ''
          try { url = String(JSON.parse(raw).subscriptionUrl ?? '').trim() } catch { url = '' }
          const result = saveSubscription(url)
          const applied = result === 'saved' || result === 'cleared'
            ? await reload()
            : result
          const body = JSON.stringify({ result, applied, reloaded: applied !== 'unknown action' })
          response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(body)
        },
      }), 'dsh-clashvpn: config route')
    })
  }

  registerRoutes()
  if (config.autostart) void start()
}
