/**
 * dsh-clashvpn — the bundled mihomo core, started and reported by the Host.
 *
 * The core is a plain proxy engine: it reads a Clash configuration from the data directory and
 * exposes `external-controller` on loopback, on by default, so the settings card and any future
 * node switcher talk to it over HTTP instead of guessing. Everything here is optional at runtime:
 * a build without the core binary reports `installed: false` and the rest of the Host is unaffected.
 */
import { dirname, join } from 'node:path'
import { ensureConfig, coreVersion, killCore, listProxies, pidAlive, resolveBinary, startCore } from './lib/mihomo.js'

export const name = 'dsh-clashvpn'

/**
 * Product data directory this plugin keeps its configuration under.
 *
 * The Host runs under the runtime node the installer staged, so `<install>/data` is two levels
 * above that interpreter; `DSH_HOME` overrides it when the launcher sets one.
 * @returns the absolute data directory.
 */
function resolveHome() {
  if (typeof process.env.DSH_HOME === 'string' && process.env.DSH_HOME.trim() !== '') return process.env.DSH_HOME
  return join(dirname(process.execPath), '..', '..', '..', 'data')
}

/**
 * Normalise the row config.
 * @param raw - configured values, all optional.
 * @param home - product home directory.
 * @returns the settings this plugin runs with.
 */
function resolveConfig(raw, home) {
  const source = raw !== null && typeof raw === 'object' ? raw : {}
  return {
    enabled: source.enabled !== false,
    binary: typeof source.binary === 'string' ? source.binary : '',
    dataDir: typeof source.dataDir === 'string' && source.dataDir.trim() !== '' ? source.dataDir : home + '/clashvpn',
    mixedPort: Number.isInteger(source.mixedPort) ? source.mixedPort : 7898,
    controllerPort: Number.isInteger(source.controllerPort) ? source.controllerPort : 9098,
    autostart: source.autostart === true,
  }
}

/**
 * Mount the core and its routes.
 * @param ctx - plugin context.
 * @param rawConfig - row configuration.
 */
export function apply(ctx, rawConfig) {
  const home = resolveHome()
  const config = resolveConfig(rawConfig, home)
  if (!config.enabled) return
  const state = { pid: 0, lastError: '' }

  /** Resolve the core and its configuration, or explain why not. */
  function prepared() {
    const binary = resolveBinary(config.binary)
    if (binary === undefined) return { error: 'mihomo core not found next to the application' }
    try {
      const configPath = ensureConfig({ dataDir: config.dataDir, mixedPort: config.mixedPort, controllerPort: config.controllerPort })
      return { binary, configPath }
    } catch (error) {
      return { error: error instanceof Error ? error.message : String(error) }
    }
  }

  /** Start the core once. @returns a short status line. */
  async function start() {
    if (state.pid !== 0 && pidAlive(state.pid)) return 'already running'
    const ready = prepared()
    if (ready.error !== undefined) { state.lastError = ready.error; return ready.error }
    const started = startCore({ binary: ready.binary, dataDir: config.dataDir, configPath: ready.configPath })
    if (started.error !== undefined) { state.lastError = started.error; return started.error }
    state.pid = started.child.pid ?? 0
    state.lastError = ''
    return 'started'
  }

  /** Stop the core. @returns a short status line. */
  function stop() {
    if (state.pid === 0) return 'not running'
    killCore(state.pid)
    state.pid = 0
    return 'stopped'
  }

  /** One observation for the status route. */
  async function observation() {
    const binary = resolveBinary(config.binary)
    const version = await coreVersion(config.controllerPort)
    const proxies = version === undefined ? undefined : await listProxies(config.controllerPort)
    return {
      installed: binary !== undefined,
      binary: binary ?? '',
      running: version !== undefined || (state.pid !== 0 && pidAlive(state.pid)),
      pid: state.pid,
      version: version ?? '',
      mixedPort: config.mixedPort,
      controller: 'http://127.0.0.1:' + String(config.controllerPort),
      proxies: proxies === undefined ? 0 : Object.keys(proxies).length,
      configPath: config.dataDir + '/config.yaml',
      lastError: state.lastError,
    }
  }

  /** Register the loopback routes; a Host without a web server keeps the plugin idle. */
  function registerRoutes() {
    ctx.inject(['webServer'], (web) => {
      web.effect(() => web.webServer.register({
        kind: 'exact',
        path: '/dsh-clashvpn/status',
        handler: async (request, response) => {
          if (request.method !== 'GET' && request.method !== 'HEAD') {
            response.writeHead(405, { allow: 'GET, HEAD' }).end()
            return
          }
          const body = JSON.stringify(await observation())
          response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(request.method === 'HEAD' ? undefined : body)
        },
      }), 'dsh-clashvpn: status route')
      web.effect(() => web.webServer.register({
        kind: 'exact',
        path: '/dsh-clashvpn/control',
        handler: async (request, response) => {
          if (request.method !== 'POST') {
            response.writeHead(405, { allow: 'POST' }).end()
            return
          }
          const url = new URL(request.url ?? '/', 'http://clashvpn.invalid')
          const action = url.searchParams.get('action')
          const result = action === 'start' ? await start() : action === 'stop' ? stop() : 'unknown action'
          response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(JSON.stringify({ result, status: await observation() }))
        },
      }), 'dsh-clashvpn: control route')
    })
  }

  registerRoutes()
  if (config.autostart) void start()
}
