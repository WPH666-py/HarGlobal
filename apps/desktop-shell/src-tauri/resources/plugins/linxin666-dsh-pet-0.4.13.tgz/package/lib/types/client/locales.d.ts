/**
 * dsh-pet locale dictionaries (zh/en).
 * @module @linxin666/dsh-pet/client/locales
 */
/** Dictionary namespace this package registers. */
export declare const NS = "pet";
/** Chinese copy. */
export declare const zh: {
    readonly 'pet.feed': "喂食";
    readonly 'pet.hide': "隐藏";
    readonly 'pet.rename': "改名";
    readonly 'pet.confirm': "确定";
    readonly 'pet.namePlaceholder': "输入新名字";
    readonly 'pet.summon': "召唤{name}";
    readonly 'pet.rank': "亲密度 {rank}";
    readonly 'pet.rank.name.\u5E7C\u9CB8': "幼鲸";
    readonly 'pet.rank.name.\u4F19\u4F34': "伙伴";
    readonly 'pet.rank.name.\u631A\u53CB': "挚友";
    readonly 'pet.rank.name.\u6DF1\u6D77\u7F81\u7ECA': "深海羁绊";
    readonly 'pet.rank.name.\u5FC3\u6709\u7075\u7280': "心有灵犀";
    readonly 'pet.rank.name.\u4F20\u8BF4\u7F81\u7ECA': "传说羁绊";
    readonly 'pet.rank.name.\u795E\u8BDD\u7F81\u7ECA': "神话羁绊";
    readonly 'pet.rank.name.\u6C38\u6052\u4E4B\u5951': "永恒之契";
    readonly 'pet.rank.name.\u9CB8\u751F\u5171\u6E21': "鲸生共渡";
    readonly 'pet.points': "{points} 点";
    readonly 'pet.treats': "小鱼干 ×{n}";
    readonly 'pet.state.loading': "宠物正在赶来…";
    readonly 'pet.state.error': "宠物迷路了（连接失败）";
    readonly 'pet.renderer.unavailable': "这只宠物需要的渲染器（{renderer}）在当前版本不可用。";
    readonly 'pet.live2d.core-missing': "Live2D 核心未安装：请把官方 live2dcubismcore.min.js 放入 $DSH_HOME/pets/.runtime/ 后刷新（步骤见宠物插件 README）。";
    readonly 'pet.live2d.vendor-missing': "Live2D 组件缺失，请升级宠物插件。";
    readonly 'pet.live2d.load-failed': "Live2D 模型加载失败，请检查该宠物目录的完整性。";
    readonly 'pet.openSessionHint': "点击跳转到对应会话";
    readonly 'pet.gameplay.menu': "玩法";
    readonly 'pet.gameplay.work': "打工";
    readonly 'pet.gameplay.stopWork': "收工";
    readonly 'pet.gameplay.sleep': "休息";
    readonly 'pet.gameplay.wake': "起床";
    readonly 'pet.gameplay.shop': "商店";
    readonly 'pet.gameplay.skin': "皮肤";
    readonly 'pet.gameplay.skinDefault': "默认";
    readonly 'pet.gameplay.back': "返回";
    readonly 'pet.gameplay.buy': "购买";
    readonly 'pet.gameplay.insufficient': "{currency}不足";
    readonly 'pet.gameplay.prize': "中奖 +{amount} {currency}";
    readonly 'pet.gameplay.working': "打工中";
    readonly 'pet.gameplay.sleeping': "睡觉中";
    readonly 'pet.gameplay.stat.hunger': "饱食";
    readonly 'pet.gameplay.stat.mood': "心情";
    readonly 'pet.gameplay.stat.energy': "精力";
    readonly 'pet.gameplay.stat.affection': "好感";
    readonly 'pet.gameplay.currency.treats': "小鱼干";
    readonly 'pet.moreSessions': "展开其余 {n} 个会话的气泡";
    readonly 'pet.collapseSessions': "收起会话气泡";
    readonly 'settings.title': "宠物";
    readonly 'settings.description': "选一只宠物，摆在页面的角落里。";
    readonly 'settings.pet': "宠物";
    readonly 'settings.petHint': "名字跟着宠物走，在宠物面板里改。";
    readonly 'settings.displayGroup': "显示";
    readonly 'settings.bubbleGroup': "气泡";
    readonly 'settings.decoration': "状态装饰";
    readonly 'settings.decorationHint': "气泡里带上喷水鲸鱼这类装饰。";
    readonly 'settings.statusBubbles': "状态气泡";
    readonly 'settings.statusBubblesHint': "宠物报告正在思考、正在用哪个工具。";
    readonly 'settings.visible': "显示宠物";
    readonly 'settings.visibleHint': "藏起来后可在输入区召唤回来。";
    readonly 'settings.size': "大小（px）";
    readonly 'settings.sizeHint': "宠物的高度。";
    readonly 'settings.bubbleScale': "气泡字号";
    readonly 'settings.bubbleScaleHint': "字号随宠物缩放，再乘上这个倍数。";
    readonly 'settings.right': "距右侧（px）";
    readonly 'settings.rightHint': "离窗口右边的距离。";
    readonly 'settings.bottom': "距底部（px）";
    readonly 'settings.bottomHint': "离窗口底边的距离。";
    readonly 'settings.inherit': "默认";
    readonly 'settings.on': "开";
    readonly 'settings.off': "关";
    readonly 'settings.overridden': "已修改";
    readonly 'settings.reset': "恢复默认";
    readonly 'settings.notExposed': "这个版本的 DSH 没有开放宠物的设置，可直接编辑 $DSH_HOME/settings.yaml。";
    readonly 'settings.readOnly': "设置只读。";
    readonly 'settings.expand': "展开设置";
    readonly 'settings.collapse': "收起设置";
    readonly 'settings.saveFailed': "没有保存成功，输入的值还留着。";
    readonly 'settings.invalidNumber': "填一个数字，留空用默认值。";
};
/** English copy. */
export declare const en: {
    readonly 'pet.feed': "Feed";
    readonly 'pet.hide': "Hide";
    readonly 'pet.rename': "Rename";
    readonly 'pet.confirm': "OK";
    readonly 'pet.namePlaceholder': "Enter a new name";
    readonly 'pet.summon': "Summon {name}";
    readonly 'pet.rank': "Affinity {rank}";
    readonly 'pet.rank.name.\u5E7C\u9CB8': "Baby Whale";
    readonly 'pet.rank.name.\u4F19\u4F34': "Companion";
    readonly 'pet.rank.name.\u631A\u53CB': "Close Friend";
    readonly 'pet.rank.name.\u6DF1\u6D77\u7F81\u7ECA': "Deep Sea Bond";
    readonly 'pet.rank.name.\u5FC3\u6709\u7075\u7280': "Kindred Spirit";
    readonly 'pet.rank.name.\u4F20\u8BF4\u7F81\u7ECA': "Legendary Bond";
    readonly 'pet.rank.name.\u795E\u8BDD\u7F81\u7ECA': "Mythic Bond";
    readonly 'pet.rank.name.\u6C38\u6052\u4E4B\u5951': "Eternal Covenant";
    readonly 'pet.rank.name.\u9CB8\u751F\u5171\u6E21': "Lifelong Companion";
    readonly 'pet.points': "{points} pts";
    readonly 'pet.treats': "Treats ×{n}";
    readonly 'pet.state.loading': "The pet is on its way…";
    readonly 'pet.state.error': "The pet is lost (connection failed)";
    readonly 'pet.renderer.unavailable': "This pet needs a renderer ({renderer}) that is not available in this build.";
    readonly 'pet.live2d.core-missing': "Live2D Cubism Core is not installed: place the official live2dcubismcore.min.js under $DSH_HOME/pets/.runtime/ and refresh (see the pet plugin README).";
    readonly 'pet.live2d.vendor-missing': "The Live2D component is missing; please update the pet plugin.";
    readonly 'pet.live2d.load-failed': "The Live2D model failed to load; check the pet directory is complete.";
    readonly 'pet.openSessionHint': "Click to jump to this session";
    readonly 'pet.gameplay.menu': "Play";
    readonly 'pet.gameplay.work': "Work";
    readonly 'pet.gameplay.stopWork': "Stop work";
    readonly 'pet.gameplay.sleep': "Sleep";
    readonly 'pet.gameplay.wake': "Wake up";
    readonly 'pet.gameplay.shop': "Shop";
    readonly 'pet.gameplay.skin': "Skin";
    readonly 'pet.gameplay.skinDefault': "Default";
    readonly 'pet.gameplay.back': "Back";
    readonly 'pet.gameplay.buy': "Buy";
    readonly 'pet.gameplay.insufficient': "Not enough {currency}";
    readonly 'pet.gameplay.prize': "Prize +{amount} {currency}";
    readonly 'pet.gameplay.working': "Working";
    readonly 'pet.gameplay.sleeping': "Sleeping";
    readonly 'pet.gameplay.stat.hunger': "Hunger";
    readonly 'pet.gameplay.stat.mood': "Mood";
    readonly 'pet.gameplay.stat.energy': "Energy";
    readonly 'pet.gameplay.stat.affection': "Affection";
    readonly 'pet.gameplay.currency.treats': "Treats";
    readonly 'pet.moreSessions': "Expand {n} more session bubbles";
    readonly 'pet.collapseSessions': "Collapse session bubbles";
    readonly 'settings.title': "Pet";
    readonly 'settings.description': "Pick a pet to sit in a corner of the page.";
    readonly 'settings.pet': "Pet";
    readonly 'settings.petHint': "Each pet keeps its own name; rename it from the pet panel.";
    readonly 'settings.displayGroup': "Display";
    readonly 'settings.bubbleGroup': "Bubbles";
    readonly 'settings.decoration': "Status decoration";
    readonly 'settings.decorationHint': "Bubbles carry ornaments like the spouting whale.";
    readonly 'settings.statusBubbles': "Status bubbles";
    readonly 'settings.statusBubblesHint': "The pet reports when it is thinking and which tool it is using.";
    readonly 'settings.visible': "Show the pet";
    readonly 'settings.visibleHint': "A hidden pet comes back from the input row.";
    readonly 'settings.size': "Size (px)";
    readonly 'settings.sizeHint': "How tall the pet stands.";
    readonly 'settings.bubbleScale': "Bubble text";
    readonly 'settings.bubbleScaleHint': "Text follows the pet size, times this factor.";
    readonly 'settings.right': "Right inset (px)";
    readonly 'settings.rightHint': "Distance from the right edge of the window.";
    readonly 'settings.bottom': "Bottom inset (px)";
    readonly 'settings.bottomHint': "Distance from the bottom edge of the window.";
    readonly 'settings.inherit': "Default";
    readonly 'settings.on': "On";
    readonly 'settings.off': "Off";
    readonly 'settings.overridden': "Changed";
    readonly 'settings.reset': "Reset to default";
    readonly 'settings.notExposed': "This DSH version does not open the pet settings here; edit $DSH_HOME/settings.yaml instead.";
    readonly 'settings.readOnly': "Settings are read-only.";
    readonly 'settings.expand': "Show settings";
    readonly 'settings.collapse': "Hide settings";
    readonly 'settings.saveFailed': "Not saved; what you typed is still there.";
    readonly 'settings.invalidNumber': "Enter a number, or leave it empty for the default.";
};
/** Key union for this namespace. */
export type PetKey = keyof typeof zh;
/** The settings-card slice of the pet dictionary. */
export type SettingsCardKey = PetKey;
/**
 * Active dictionary, picked by the document language at call time. The pet
 * mounts as a global floating surface (not a session-scoped slot), so it has
 * no framework locale seat and resolves its copy the same tiny way the
 * task-board's DOM-injected surface does.
 */
export declare function dictionary(): Record<PetKey, string>;
/**
 * Translate a key with optional `{name}` template params. Mirrors the slot
 * `Translate` contract `(key, params?) => string` so it can be handed to the
 * same components that used to receive the framework-injected `t` seat. The
 * key is typed loosely (`string`) so the function is assignable to the slot's
 * `TranslateNS<'pet'>` (whose key domain also spans the shared common
 * vocabulary); a missing key degrades to the key itself rather than throwing.
 */
export declare function t(key: string, params?: Record<string, unknown>): string;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** dsh-pet UI copy. */
        pet: PetKey;
    }
}
//# sourceMappingURL=locales.d.ts.map