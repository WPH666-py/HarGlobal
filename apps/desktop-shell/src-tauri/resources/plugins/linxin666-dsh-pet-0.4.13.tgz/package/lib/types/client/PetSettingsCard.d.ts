/**
 * The pet settings card: pet selection plus display layout, staged over the
 * 'pet' profile entry's own configuration (a plugin's settings ARE its Cordis
 * Config since 0.1.7, so the Host serves one form per profile entry).
 * Rendered as an always-open first-level settings page; the section wrapper
 * below mounts it as the content of the top-level 'settings.section' nav
 * entry. The petId choices come from the registry endpoint ('/api/pet/pets') —
 * the same list the sprite renders from — so the card carries no per-pet
 * knowledge.
 */
import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { SnapshotStore } from '@deepseek-ai/dsh-client-store';
import { type PetPreviewDefinition } from './PetPreview.tsx';
import { type CardActions, type CardShell, type FieldState as CardFieldState } from './settings-form.ts';
/** The pet's settings fields this card edits (the namespace's full schema). */
export interface PetSettings {
    /** Master switch for the plugin. */
    enabled?: boolean;
    /** Master switch. */
    visible?: boolean;
    /** Scale of the rendered pet in px (sprite cell height). */
    size?: number;
    /** Horizontal inset from the viewport right edge, px. */
    right?: number;
    /** Vertical inset from the viewport bottom edge, px. */
    bottom?: number;
    /** Bubble typography multiplier on the automatic size following (#1549). */
    bubbleScale?: number;
    /** Selected pet id (a registry entry). */
    petId?: string;
    /** Status-decoration master switch (pet-center M5, #567). */
    decorationEnabled?: boolean;
    /** Whether the pet's own session/status bubbles render (issue #6). */
    statusBubbles?: string;
}
/** What the pet settings card renders. */
export interface PetSettingsCardState extends CardShell {
    /** The aggregate shell has no Host settings form; pet selection uses its own persisted API. */
    petSelectionFallback: boolean;
    /** Plugin master switch. */
    enabled: CardFieldState;
    /** Master switch. */
    visible: CardFieldState;
    /** Pet scale. */
    size: CardFieldState;
    /** Right inset. */
    right: CardFieldState;
    /** Bottom inset. */
    bottom: CardFieldState;
    /** Bubble typography multiplier. */
    bubbleScale: CardFieldState;
    /** Selected pet. */
    petId: CardFieldState;
    /** Status-decoration master switch. */
    decorationEnabled: CardFieldState;
    /** Whether the pet's own session/status bubbles render. */
    statusBubbles: CardFieldState;
    /** Pet choices (registry ids + display names), loaded from the host. */
    petChoices: readonly {
        value: string;
        label: string;
    }[];
    /** The same registry entries with the visual data their thumbnails need. */
    petPreviews: readonly PetPreviewDefinition[];
}
/** The registration-side face the card's slot entry injects. */
export interface PetSettingsCardFace extends CardActions {
    hooks: {
        /** Card snapshot bound by the renderer as usePetSettingsCard. */
        petSettingsCard: SnapshotStore<PetSettingsCardState>;
    };
    /**
     * Ask the card for the pet registry again. The pet API only exists while the
     * plugin is enabled, so opening the master switch has to be able to re-ask
     * instead of leaving the picker empty until the page reloads.
     */
    refreshPets(): void;
}
/**
 * The spans the coarse sliders cover, spelled as literals for the same reason.
 * Size and bubble scale are the schema's own bounds (src/persist.ts); the
 * insets reach the schema's far end only by typing, so their slider covers the
 * distances a window can show.
 */
export declare const SIZE_RANGE: {
    min: number;
    max: number;
    step: number;
};
export declare const INSET_RANGE: {
    min: number;
    max: number;
    step: number;
};
export declare const BUBBLE_SCALE_RANGE: {
    min: number;
    max: number;
    step: number;
};
/** Bridges the 'pet' scope onto the card's staged form. */
export declare class PetSettingsCardController {
    private readonly form;
    private readonly store;
    private readonly petChoices;
    private readonly petLabels;
    private petPreviews;
    private selectedPetId;
    private selectedVisible;
    private stagedPetId;
    private stagedVisible;
    private savingPet;
    /** A fallback pick made while a write was in flight. */
    private fallbackQueued;
    private petSaveFailed;
    private loaded;
    /** A registry request is in flight. */
    private loading;
    private attempts;
    private disposed;
    /** Pending deferred-load or retry timer; cancelled by dispose(). */
    private pendingTimer;
    /** @param scope - the bound configuration form for the 'pet' entry. */
    constructor(scope: ConfigForm<PetSettings>);
    /** Resolve the registry choices once (retried a few times on failure). */
    private loadPets;
    /**
     * Re-read the registry on demand. The pet API is registered only while the
     * plugin is enabled, so the first read can fail while the master switch is
     * off; this lets the card try again the moment the switch opens instead of
     * waiting for a page reload.
     */
    refreshPets(): void;
    private loadPetState;
    private fallback;
    /**
     * The visibility the fallback switch renders: the staged draft when the user
     * moved it, the persisted value otherwise. There is no user layer to override
     * here, so the field is never marked overridden.
     */
    private fallbackVisible;
    /**
     * Persist the staged selection and visibility through the pet API — the only
     * writer available when the aggregate shell serves this card, since there is
     * no Host settings form to mutate — then confirm the read-back before the
     * drafts are cleared. A refused write puts both picks back to what the pet
     * persisted. A pick made while a write is in flight runs once it settles.
     */
    private saveFallback;
    private projection;
    /**
     * Build the face the card's slot registration injects.
     * @returns the card's snapshot and its form actions.
     */
    inject(): PetSettingsCardFace;
    /**
     * Release the card's scope subscription, bound stores and pending load
     * timers; the slot disposer calls this on teardown.
     */
    dispose(): void;
}
/** Props the renderer binds for the pet settings card. */
export type PetSettingsCardProps = PropsLocale<'pet'> & InjectFace<PetSettingsCardFace>;
/**
 * Render the pet settings card.
 * @param props - locale copy, the card snapshot, and its form actions.
 * @returns the card.
 */
export declare function PetSettingsCard(props: PetSettingsCardProps): import("react").JSX.Element;
/** Props the settings section binds for the pet card page. */
export type PetSettingsSectionProps = (PropsRuntime<'settings.section'> | PropsRuntime<'web-ui.extension'>) & PropsLocale<'pet'> & InjectFace<PetSettingsCardFace>;
/** Render the pet settings card as a first-level settings page. */
export declare function PetSettingsSection(props: PetSettingsSectionProps): ReactNode;
//# sourceMappingURL=PetSettingsCard.d.ts.map