/**
 * The pet settings page's contribution: the Web Extensions parent mounts it
 * through its page service, while a standalone install keeps the original
 * first-level settings section.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type PetSettingsCardController } from './PetSettingsCard.tsx';
/**
 * Register exactly one reachable pet entry and follow the parent across late
 * loading or teardown. The controller belongs to apply(), not a registration,
 * so moving seats never resets staged edits or subscriptions.
 * @returns the page contribution's disposer.
 */
export declare function installPetSettingsRegistration(ctx: ClientContext, controller: PetSettingsCardController): () => void;
//# sourceMappingURL=settings-registration.d.ts.map