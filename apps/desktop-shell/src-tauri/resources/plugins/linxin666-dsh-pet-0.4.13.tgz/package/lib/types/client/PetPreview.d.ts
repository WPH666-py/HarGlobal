/** Lightweight, static pet thumbnails built from the registry's existing assets. */
import type { PetDefinition } from '../registry.ts';
/** Registry data needed by a thumbnail; older hosts may serve only id/name. */
export type PetPreviewDefinition = Pick<PetDefinition, 'id' | 'displayName'> & Partial<Pick<PetDefinition, 'renderer' | 'cell' | 'columns' | 'atlasRows' | 'atlasUrl' | 'frames2d'>>;
/**
 * Render the atlas's first sprite cell or a frames2d idle frame. Live2d and
 * incomplete legacy responses degrade to a text mark instead of a broken image.
 */
export declare function PetPreview(props: {
    pet: PetPreviewDefinition;
}): import("react").JSX.Element;
//# sourceMappingURL=PetPreview.d.ts.map