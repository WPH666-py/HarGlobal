/**
 * Pet sprite companion component — the browser half's centerpiece. Renders a
 * fixed-position floating sprite (React portal onto document.body), plays
 * the track matching the host animation snapshot, and exposes the
 * interaction surface: click to pet, hover panel with feed/rename/hide, drag
 * to reposition (persisted via setConfig). Everything visual comes from the
 * pet definition the host serves ('/api/pet/pets' + the state snapshot's
 * pet id), so one component renders every registry entry.
 * @module @linxin666/dsh-pet/client/PetSprite
 */
import type { ReactNode, ReactPortal } from 'react';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import { type PetDisplayConfig } from '../persist.ts';
import type { PetStateView } from '../service.ts';
import type { PetDefinition } from '../registry.ts';
import type { GameplayBus } from './gameplay-hud.ts';
import type { PetFeedback } from './pet-store.ts';
import { NS } from './locales.ts';
/** Props injected by the plugin apply body (store actions + locale). */
export interface PetSpriteProps {
    /** Latest host snapshot; null while loading. */
    snapshot: PetStateView | null;
    /** The selected pet's registry definition (atlas URL + geometry + tracks). */
    definition: PetDefinition;
    /** Display configuration (persisted by the host). */
    display: PetDisplayConfig;
    /** Active reaction bubble, if any. */
    feedback: PetFeedback | null;
    /** Pet the sprite (click). */
    onPet: () => void;
    /** Feed the sprite (panel button). */
    onFeed: () => void;
    /** Hide the sprite (panel button). */
    onHide: () => void;
    /** Persist a drag position. */
    onDragEnd: (right: number, bottom: number) => void;
    /** Drag gesture notifications for renderers with a drag track (frames2d). */
    onDraggingChange?: (dragging: boolean) => void;
    /** Rename the selected pet (persisted by the host). */
    onRename: (name: string) => void;
    /**
     * Report a click on one plugin-registered action (issue #6). The buttons
     * themselves come from the state snapshot's `panelActions` slice, so the
     * panel renders exactly the registrations the host serves and adds nothing
     * of its own.
     */
    onPanelAction: (id: string) => void;
    /** Navigate to the session one status bubble reports on. */
    onOpenSession: (sessionId: string) => void;
    /** Clear the reaction bubble (after its CSS animation). */
    onFeedbackDone: () => void;
    /**
     * Custom visual replacing the sprite2d atlas animation (pet-center M3).
     * The chrome (drag, bubbles, panel, tap economy) is untouched: the visual
     * renders inside the sprite box, and the atlas load + frame loop skip.
     */
    visual?: ReactNode;
    /**
     * Gameplay overlay (miku-pet generalization): rendered inside the float
     * container so hover containment and stacking work unchanged. Absent for
     * pets without a gameplay block.
     */
    hud?: ReactNode;
    /**
     * Gameplay tap sink: receives the tap point as sprite-box fractions
     * (0..1). When present the chrome reports the tap IN ADDITION to the
     * affinity pet; the HUD decides zones/no-ops.
     */
    onGameplayTap?: (fractionX: number, fractionY: number) => void;
    /**
     * Gameplay entry (miku-pet generalization): when present the hover panel
     * renders a 玩法 action that opens/closes the gameplay card. The chrome
     * wires it to the HUD through the per-pet bus (openCard), mirroring the
     * onGameplayTap sink. Absent for pets without a gameplay block.
     */
    onGameplayMenu?: () => void;
    /** Disable the drag gesture (gameplay work mode blocks dragging). */
    dragDisabled?: boolean;
    /**
     * Per-pet coordination bus. The chrome registers `walk` here so the gameplay
     * HUD can roam the pet (the same two-way shape the HUD's `tap` uses).
     */
    bus?: GameplayBus;
    /**
     * DOM node the floating chrome portals into. Defaults to document.body
     * (the legacy behavior); the plugin apply passes its owning root (the
     * [data-dsh-plugin="pet"] container) so the root owns the whole surface
     * and a root-keyed suppressor (the portrait mobile layer) hides the pet
     * as one unit instead of missing the portaled sprite.
     */
    portalTarget?: Element;
    /** Locale translate seat (namespace-bound). */
    t: TranslateNS<typeof NS>;
    /**
     * Active UI locale id, used to pick a pet-declared English rank name
     * (`rankEn`). Defaults to the document language for direct mounts/tests.
     */
    lang?: string;
}
/**
 * The floating pet. The spritesheet frame advances on a timer scheduled for the
 * current frame's remaining time (per-frame durations come from the
 * definition's tracks), so the loop wakes once per frame change instead of once
 * per screen refresh; the atlas image is loaded once and the background
 * position is written straight to the sprite element (no per-frame React
 * state). Roaming writes the sprite's position the same way (issue #17).
 */
export declare function PetSprite(props: PetSpriteProps): ReactPortal;
//# sourceMappingURL=PetSprite.d.ts.map