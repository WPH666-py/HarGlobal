/**
 * Coarse adjustment for a bounded number: resting the pointer on the control
 * (or moving focus into it) raises a small bubble holding a slider across the
 * field's whole range, so a large change is one drag instead of many presses
 * or a retyped value. The control itself stays the precise entry.
 *
 * The bubble belongs to the anchor's subtree, so moving from the control onto
 * the bubble never counts as leaving. It opens after a short rest and closes a
 * moment after the pointer and focus have both gone, so crossing the control
 * on the way elsewhere does not flash it. While a drag is in progress the
 * bubble stays put even if the pointer strays off it.
 *
 * Dragging reports each value through `onInput`, so the field shows it live;
 * releasing the thumb, or a key press on it, reports `onCommit` once. The
 * bubble opens on the side of the control that has room inside the nearest
 * scrolling ancestor, so a row near the top of a settings page does not hang
 * its bubble under the page edge.
 */

import { useEffect, useRef, useState, type ChangeEvent, type CSSProperties, type KeyboardEvent, type ReactNode } from 'react'
import css from './settings-card.module.css'

/** Rest on the control before the bubble opens. */
const OPEN_DELAY_MS = 220
/** Grace after pointer and focus have left before the bubble closes. */
const CLOSE_DELAY_MS = 200
/** Room the bubble needs between the control and the scroller's edge. */
const BUBBLE_ROOM_PX = 64

/** Props of {@link RangeBubble}. */
export interface RangeBubbleProps {
  /** Lowest value the slider reaches. */
  min: number
  /** Highest value the slider reaches. */
  max: number
  /** Slider granularity. */
  step: number
  /** Current value; a value outside the range parks the thumb at the nearer end. */
  value: number
  /** Accessible name of the slider. */
  label: string
  /** Disables the bubble along with the control. */
  disabled?: boolean
  /** Each value while the thumb moves. */
  onInput: (value: number) => void
  /** The value the thumb was released on, once per drag or key press. */
  onCommit: (value: number) => void
  /** The precise control the bubble hangs off. */
  children: ReactNode
}

/** The nearest ancestor that scrolls vertically, or the viewport's root. */
function scroller(node: HTMLElement): HTMLElement {
  for (let parent = node.parentElement; parent !== null; parent = parent.parentElement) {
    const overflow = getComputedStyle(parent).overflowY
    if (overflow === 'auto' || overflow === 'scroll') return parent
  }
  return node.ownerDocument.documentElement
}

/**
 * Render the control with its coarse-adjustment bubble.
 * @param props - the range, the value and the two report callbacks.
 * @returns the anchor holding the control and the bubble.
 */
export function RangeBubble(props: RangeBubbleProps): ReactNode {
  const { min, max, step, disabled = false } = props
  const [open, setOpen] = useState(false)
  const [side, setSide] = useState<'above' | 'below'>('above')
  const [live, setLive] = useState<number | null>(null)
  const anchorRef = useRef<HTMLDivElement | null>(null)
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
  const hovered = useRef(false)
  const focused = useRef(false)
  const dragging = useRef(false)

  useEffect(() => () => { clearTimeout(timer.current) }, [])
  useEffect(() => {
    if (disabled) {
      clearTimeout(timer.current)
      setOpen(false)
    }
  }, [disabled])

  const show = (): void => {
    const anchor = anchorRef.current
    if (anchor !== null) {
      const room = anchor.getBoundingClientRect().top - scroller(anchor).getBoundingClientRect().top
      setSide(room >= BUBBLE_ROOM_PX ? 'above' : 'below')
    }
    setOpen(true)
  }
  const schedule = (): void => {
    clearTimeout(timer.current)
    if (disabled) return
    if (hovered.current || focused.current || dragging.current) {
      if (!open) timer.current = setTimeout(show, focused.current ? 0 : OPEN_DELAY_MS)
      return
    }
    timer.current = setTimeout(() => { setOpen(false) }, CLOSE_DELAY_MS)
  }

  const commit = (value: number): void => {
    dragging.current = false
    setLive(null)
    props.onCommit(value)
    schedule()
  }
  const onChange = (event: ChangeEvent<HTMLInputElement>): void => {
    const value = Number(event.target.value)
    setLive(value)
    props.onInput(value)
  }
  const onKeyUp = (event: KeyboardEvent<HTMLInputElement>): void => {
    if (live !== null) commit(live)
    if (event.key === 'Escape') {
      clearTimeout(timer.current)
      setOpen(false)
    }
  }
  const shown = live ?? Math.min(max, Math.max(min, props.value))

  return (
    <div
      ref={anchorRef}
      className={css.rangeAnchor}
      onPointerEnter={() => { hovered.current = true; schedule() }}
      onPointerLeave={() => { hovered.current = false; schedule() }}
      onFocus={() => { focused.current = true; schedule() }}
      onBlur={(event) => {
        if (event.currentTarget.contains(event.relatedTarget as Node | null)) return
        focused.current = false
        if (live !== null) commit(live)
        else schedule()
      }}
    >
      {props.children}
      <div className={css.rangeBubble} data-open={open ? '' : undefined} data-side={side}>
        <input
          type="range"
          className={css.rangeSlider}
          min={min}
          max={max}
          step={step}
          value={shown}
          aria-label={props.label}
          tabIndex={open ? 0 : -1}
          disabled={disabled}
          style={{ '--range-fill': `${((shown - min) / (max - min)) * 100}%` } as CSSProperties}
          onPointerDown={() => { dragging.current = true }}
          onPointerUp={(event) => { commit(Number(event.currentTarget.value)) }}
          onPointerCancel={(event) => { commit(Number(event.currentTarget.value)) }}
          onChange={onChange}
          onKeyUp={onKeyUp}
        />
        <span className={css.rangeEnds} aria-hidden="true">
          <span>{min}</span>
          <span>{max}</span>
        </span>
      </div>
    </div>
  )
}
