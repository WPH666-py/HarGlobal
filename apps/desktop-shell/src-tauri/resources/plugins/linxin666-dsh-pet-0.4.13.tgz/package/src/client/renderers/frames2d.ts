/**
 * frames2d renderer — plays the free-form named frame-sequence tracks of a
 * frames2d pet (manifest v2 'frames2d' block). The pet center picks the
 * track from the ActivityPhase stream (phase -> track map, idle fallback);
 * the gameplay driver may force a track through the handle's setState
 * override (drag/work/sleep/shop...), and a finished non-loop track settles
 * into its fallback, releasing the override when the fallback matches the
 * phase-mapped track. Rendering never throws: a broken track list degrades
 * to the first decodable frame, and the 1.2 s stall watchdog re-kicks the
 * playback chain after timer throttling.
 *
 * Frame presentation has two modes picked once at mount by capability
 * probing:
 * - Canvas bitmap buffer (default where createImageBitmap/fetch/2D context
 *   exist): frames are decoded once into an ImageBitmap on demand, with a
 *   bounded look-ahead window over the playing track, and drawn onto one
 *   <canvas>. Steady-state playback issues zero DOM mutations and re-decodes
 *   only what the retention budget evicted: decoded frames are held under
 *   MAX_RETAINED_BYTES, so a long-lived pet that plays every track of every
 *   skin cannot pin every bitmap for the life of the page (measured hotspot:
 *   swapping <img>.src per frame drove image decode + invalidation every tick).
 * - Classic <img> fallback (jsdom/tests or missing APIs): identical to the
 *   historical behavior - cache-warm Image elements plus guarded src swaps,
 *   so environments without modern decoding keep working unchanged.
 *
 * @module @linxin666/dsh-pet/client/renderers/frames2d
 */

import { PET_RENDERER_API_VERSION, type PetRenderer, type PetRendererContext, type PetRendererHandle } from '../../contracts/renderer.ts'
import type { ActivityPhase } from '../../state.ts'

/** One track as served inside the pet definition (browser URLs). */
export interface Frames2dTrackConfig {
  frames: string[]
  durations: number[]
  loop: boolean
  fallback?: string
}

/** The frames2d block as served inside the pet definition. */
export interface PetFrames2dConfig {
  tracks: Record<string, Frames2dTrackConfig>
  phases: Partial<Record<ActivityPhase, string>> & { idle: string }
  /** Selectable skins; each swaps the base idle target while selected. */
  skins?: Frames2dSkinConfig[]
}

/** One selectable skins entry as served inside the pet definition. */
export interface Frames2dSkinConfig {
  id: string
  label: string
  /** A declared looping track that becomes the base idle while selected. */
  idleTrack: string
  /** Click actions exclusive to this skin (roll by probability; miss → touch zones). */
  clickActions?: Frames2dSkinClickActionConfig[]
  /** Gameplay-state overrides (state -> track) swapped in while selected. */
  gameplayTracks?: Record<string, string>
}

/** One probability-rolled tap action a skin may declare. */
export interface Frames2dSkinClickActionConfig {
  track: string
  probability: number
  phrases?: string[]
}

export interface Frames2dRendererHandle extends PetRendererHandle {
  /** Force a track id (gameplay override); undefined returns to phase mapping. */
  setState(track: string | undefined): void
  /**
   * Swap the base idle target (idle phase, unmapped phases and every
   * fallback back to idle) to a declared looping track — a skin. undefined
   * restores the manifest idle track.
   */
  setIdleTrack(track: string | undefined): void
  /** The track currently playing (diagnostics and tests). */
  currentTrack(): string
}

/** Stall watchdog period: a looping track stuck longer re-kicks its chain. */
const WATCHDOG_MS = 1200

/**
 * Retention budget for decoded frame bitmaps, in bytes.
 *
 * The budget is expressed in bytes rather than in frames because a frame's
 * decoded footprint is `width * height * 4` and published pets differ by more
 * than an order of magnitude (a 512x683 frame is 1.33 MB, a 128x128 frame is
 * 64 KB): a frame count would be either useless for small atlases or too tight
 * for large ones. 128 MiB holds this repository's longest shipped track (78
 * frames, 104 MB) in full, so a running loop still re-decodes nothing, while
 * capping a pet that played every track of every skin at roughly a tenth of
 * the ~1.7 GB the unbounded memo reached.
 */
const MAX_RETAINED_BYTES = 128 * 1024 * 1024

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/** Fail-closed client-side validation of the served frames2d block. */
function validateFrames2dConfig(config: unknown): PetFrames2dConfig {
  if (!isRecord(config) || !isRecord(config.tracks) || !isRecord(config.phases)) {
    throw new Error('frames2d config requires tracks and phases objects')
  }
  const tracks: Record<string, Frames2dTrackConfig> = {}
  for (const [name, raw] of Object.entries(config.tracks)) {
    if (!isRecord(raw) || !Array.isArray(raw.frames) || raw.frames.length === 0
      || raw.frames.some(f => typeof f !== 'string' || f === '')
      || !Array.isArray(raw.durations) || raw.durations.length !== raw.frames.length
      || raw.durations.some(d => typeof d !== 'number' || !(d > 0))) {
      throw new Error('frames2d track ' + JSON.stringify(name) + ' needs same-length frames/durations')
    }
    tracks[name] = {
      frames: raw.frames as string[],
      durations: raw.durations as number[],
      loop: raw.loop !== false,
      ...(typeof raw.fallback === 'string' ? { fallback: raw.fallback } : {}),
    }
  }
  const phases = config.phases as Partial<Record<ActivityPhase, string>>
  if (typeof phases.idle !== 'string' || tracks[phases.idle] === undefined) {
    throw new Error('frames2d phases.idle must name an existing track')
  }
  // Skins: keep entries whose idleTrack survives validation and loops —
  // a non-looping base idle would settle into itself forever. Click actions
  // with an unresolvable track are dropped from that skin.
  let skins: Frames2dSkinConfig[] | undefined
  if (Array.isArray(config.skins)) {
    const resolved: Frames2dSkinConfig[] = []
    for (const skin of config.skins as unknown[]) {
      if (!isRecord(skin) || typeof skin.id !== 'string' || typeof skin.label !== 'string'
        || typeof skin.idleTrack !== 'string' || skin.idleTrack === '') continue
      const target = tracks[skin.idleTrack]
      if (target === undefined || !target.loop) continue
      let clickActions: Frames2dSkinClickActionConfig[] | undefined
      if (Array.isArray(skin.clickActions)) {
        const kept: Frames2dSkinClickActionConfig[] = []
        for (const action of skin.clickActions as unknown[]) {
          if (!isRecord(action) || typeof action.track !== 'string' || action.track === ''
            || typeof action.probability !== 'number' || !(action.probability > 0) || action.probability > 1) continue
          if (tracks[action.track] === undefined) continue
          kept.push({
            track: action.track,
            probability: action.probability,
            ...(Array.isArray(action.phrases) ? { phrases: action.phrases as string[] } : {}),
          })
        }
        if (kept.length > 0) clickActions = kept
      }
      let gameplayTracks: Record<string, string> | undefined
      if (isRecord(skin.gameplayTracks)) {
        const kept: Record<string, string> = {}
        for (const [state, trackName] of Object.entries(skin.gameplayTracks)) {
          if (typeof trackName !== 'string' || trackName === '' || tracks[trackName] === undefined) continue
          kept[state] = trackName
        }
        if (Object.keys(kept).length > 0) gameplayTracks = kept
      }
      resolved.push({
        id: skin.id,
        label: skin.label,
        idleTrack: skin.idleTrack,
        ...(clickActions === undefined ? {} : { clickActions }),
        ...(gameplayTracks === undefined ? {} : { gameplayTracks }),
      })
    }
    if (resolved.length > 0) skins = resolved
  }
  return { tracks, phases: phases as PetFrames2dConfig['phases'], ...(skins === undefined ? {} : { skins }) }
}

interface DecodedFrame {
  source: ImageBitmap | HTMLImageElement
  width: number
  height: number
}

/**
 * One memoized decode job. `frame` and `bytes` appear only once the job
 * resolved with a frame — exactly the set the retention budget may release;
 * pending and failed jobs carry neither. The owning map's insertion order is
 * the LRU order (re-inserting an entry marks it most recently used).
 */
interface DecodeEntry {
  job: Promise<DecodedFrame | undefined>
  frame?: DecodedFrame
  bytes?: number
}

/**
 * Release one decoded frame. `close()` is browser-only and idempotent, so the
 * call is guarded for exotic hosts and for frames that were already released;
 * the `<img>` fallback has no close, where dropping the reference is the
 * release.
 */
function releaseFrame(frame: DecodedFrame | undefined): void {
  if (frame === undefined) return
  try {
    const maybeClose = (frame.source as { close?: () => void }).close
    if (typeof maybeClose === 'function') maybeClose.call(frame.source)
  } catch { /* already released */ }
}

export const frames2dRenderer: PetRenderer<PetFrames2dConfig> = {
  id: 'frames2d',
  apiVersion: PET_RENDERER_API_VERSION,
  validateConfig: validateFrames2dConfig,

  mount(ctx: PetRendererContext, config: PetFrames2dConfig): Frames2dRendererHandle {
    const reducedMotion = typeof window !== 'undefined'
      && typeof window.matchMedia === 'function'
      && window.matchMedia('(prefers-reduced-motion: reduce)').matches

    // Capability probe: the canvas path needs decode-to-bitmap, same-origin
    // fetch, and a real 2D context (jsdom returns null and falls back below).
    let canvas: HTMLCanvasElement | null = null
    let context2d: CanvasRenderingContext2D | null = null
    let img: HTMLImageElement | null = null
    try {
      if (typeof createImageBitmap === 'function' && typeof fetch === 'function') {
        const probe = document.createElement('canvas')
        const c2d = probe.getContext('2d')
        if (c2d !== null) {
          canvas = probe
          context2d = c2d
        }
      }
    } catch {
      canvas = null
      context2d = null
    }

    if (canvas !== null && context2d !== null) {
      canvas.dataset.dshPetFrames2d = ctx.petId
      canvas.draggable = false
      canvas.style.width = '100%'
      canvas.style.height = '100%'
      canvas.style.objectFit = 'contain'
      canvas.style.pointerEvents = 'none'
      ctx.container.appendChild(canvas)
    } else {
      img = document.createElement('img')
      img.dataset.dshPetFrames2d = ctx.petId
      img.alt = ''
      img.draggable = false
      img.style.width = '100%'
      img.style.height = '100%'
      img.style.objectFit = 'contain'
      img.style.pointerEvents = 'none'
      ctx.container.appendChild(img)
    }

    // Decode cache: one concurrent decode per URL, retained under a decoded
    // byte budget. The historical map memoized every decoded frame forever, so
    // a pet that had played all of its tracks (every skin) kept every bitmap
    // alive for the life of the page: a shipped three-skin pet measures 1276
    // frames at 512x683 RGBA, about 1.7 GB, growing monotonically. Entries now
    // carry their decoded footprint, sit in Map insertion order (delete + set
    // is an LRU touch) and the least recently used ones outside the playing
    // window are closed once MAX_RETAINED_BYTES is crossed. A failed decode
    // still resolves undefined and leaves the memo, so a transient fetch error
    // retries instead of sticking.
    const decoding = new Map<string, DecodeEntry>()
    let retainedBytes = 0
    // All frame fetches funnel through a small pool. Full-library warm passes
    // on large pets fire 1100+ requests at once, which trips the browser's
    // in-flight request limit (net::ERR_INSUFFICIENT_RESOURCES) and fails
    // whole batches of frames while starving the rest of the page. Playback
    // demand jumps ahead of the warm backlog.
    const FRAME_POOL_LIMIT = 8
    const frameQueue: Array<{ url: string; release: () => void }> = []
    let activeFrames = 0

    const decodeFrame = async (url: string): Promise<DecodedFrame | undefined> => {
      try {
        const response = await fetch(url)
        if (!response.ok) throw new Error('http ' + response.status)
        const bitmap = await createImageBitmap(await response.blob())
        return { source: bitmap, width: bitmap.width, height: bitmap.height }
      } catch {
        // Fail-open: classic Image decode keeps non-modern runtimes alive.
        return await new Promise<DecodedFrame | undefined>((resolve) => {
          try {
            const pre = new Image()
            pre.onload = (): void => {
              resolve(pre.naturalWidth > 0 ? { source: pre, width: pre.naturalWidth, height: pre.naturalHeight } : undefined)
            }
            pre.onerror = (): void => resolve(undefined)
            pre.src = url
          } catch {
            resolve(undefined)
          }
        })
      }
    }

    const pumpFrames = (): void => {
      while (activeFrames < FRAME_POOL_LIMIT && frameQueue.length > 0) {
        const queued = frameQueue.shift()!
        activeFrames += 1
        queued.release()
      }
    }

    const loadFrame = (url: string, jump = false): Promise<DecodedFrame | undefined> => {
      // Jump first: warm-enqueued frames already carry their memo, so a
      // playback demand must reorder the unstarted entry before the cache
      // lookup short-circuits.
      if (jump) {
        const index = frameQueue.findIndex((queued) => queued.url === url)
        if (index > 0) frameQueue.unshift(frameQueue.splice(index, 1)[0]!)
      }
      const cached = decoding.get(url)
      if (cached !== undefined) {
        // LRU touch: a hit means playback just asked for this frame, so it must
        // not be the next victim. Re-inserting the same entry only reorders.
        decoding.delete(url)
        decoding.set(url, cached)
        return cached.job
      }
      let release!: () => void
      const gate = new Promise<void>((resolve) => { release = resolve })
      const job: Promise<DecodedFrame | undefined> = gate.then(() => (disposed ? undefined : decodeFrame(url)))
      const entry: DecodeEntry = { job }
      job.then(
        (frame) => {
          if (frame === undefined) {
            decoding.delete(url)
            return
          }
          // A decode that lands after dispose is closed here: nothing can close
          // it later, and the map was already drained.
          if (disposed) {
            releaseFrame(frame)
            decoding.delete(url)
            return
          }
          entry.frame = frame
          entry.bytes = frame.width * frame.height * 4
          retainedBytes += entry.bytes
          // Only a resolved frame is evictable, and its decoded size is known
          // only now, so the budget is enforced here.
          enforceRetentionBudget()
        },
        () => decoding.delete(url),
      )
      void job.finally(() => {
        activeFrames -= 1
        pumpFrames()
      })
      decoding.set(url, entry)
      const queued = { url, release }
      if (jump) frameQueue.unshift(queued)
      else frameQueue.push(queued)
      pumpFrames()
      return job
    }

    /**
     * Release decoded bitmaps until the retained footprint is back under
     * MAX_RETAINED_BYTES. Two properties keep this from breaking playback:
     *
     * - The playing track's look-ahead window, plus the frame a draw is waiting
     *   on, are never released. Releasing one would hand a closed bitmap to
     *   `drawImage`, and re-decoding it would stall the next tick.
     * - Frames of any other track go first. That is what keeps a running loop
     *   warm under a budget smaller than two whole tracks: eviction reclaims the
     *   track the pet left instead of eating the cycle it is playing.
     *
     * When the protected window alone exceeds the budget nothing is released —
     * a pet whose frames are that large cannot be bounded further without
     * breaking playback, and the overshoot is then exactly one window.
     */
    function enforceRetentionBudget(): void {
      if (retainedBytes <= MAX_RETAINED_BYTES) return
      const def = config.tracks[track]
      const playing = new Set<string>(def === undefined ? [] : def.frames)
      const protectedUrls = new Set<string>()
      if (pinned !== undefined) protectedUrls.add(pinned)
      if (def !== undefined) {
        const end = Math.min(def.frames.length, frameIndex + 1 + PREFETCH_AHEAD)
        for (let index = frameIndex; index < end; index += 1) {
          const url = def.frames[index]
          if (url !== undefined) protectedUrls.add(url)
        }
      }
      // Pass 1 reclaims frames of tracks the pet is not playing; pass 2 is the
      // backstop for a single track larger than the whole budget.
      for (const foreignOnly of [true, false]) {
        for (const [url, entry] of decoding) {
          if (retainedBytes <= MAX_RETAINED_BYTES) return
          if (entry.bytes === undefined || protectedUrls.has(url)) continue
          if (foreignOnly && playing.has(url)) continue
          releaseFrame(entry.frame)
          retainedBytes -= entry.bytes
          decoding.delete(url)
        }
      }
    }

    /**
     * Bounded look-ahead window: decode only the frames playback is about to
     * need. The historical warm pass decoded every frame of every track up
     * front - a shipped pet carries ~1.1k 512x683 frames, so that pass pulls
     * tens of megabytes and retains every decoded bitmap for the life of the
     * page. Prefetching the playing track's next frames keeps loops and phase
     * switches warm while unplayed tracks (and every unselected skin's
     * frames) stay on demand, where playback jumps the queue anyway.
     */
    const PREFETCH_AHEAD = 12

    const prefetchAhead = (trackId: string, index: number): void => {
      const def = config.tracks[trackId]
      if (def === undefined) return
      const end = Math.min(def.frames.length, index + 1 + PREFETCH_AHEAD)
      for (let ahead = index + 1; ahead < end; ahead += 1) {
        const url = def.frames[ahead]
        if (url !== undefined) void loadFrame(url)
      }
    }

    let disposed = false
    let timer: ReturnType<typeof setTimeout> | undefined
    let watchdog: ReturnType<typeof setInterval> | undefined
    let track: string = config.phases.idle
    let frameIndex = 0
    let lastAdvance = Date.now()
    let override: string | undefined
    // Skin base idle: every "back to idle" target resolves through this
    // (idle phase, unmapped phases and fallbacks), so a selected skin swaps
    // the pet's resting look without touching gameplay tracks.
    let baseIdle: string = config.phases.idle
    let drawToken = 0
    let lastDrawnUrl: string | undefined
    // The frame a draw is currently awaiting. Eviction must not release it:
    // the callback below holds the bitmap and would draw a closed one.
    let pinned: string | undefined

    const trackForPhase = (phase: ActivityPhase): string => {
      const mapped = config.phases[phase]
      if (mapped === undefined) return baseIdle
      const target = mapped === config.phases.idle ? baseIdle : mapped
      return config.tracks[target] !== undefined ? target : baseIdle
    }

    /** Canvas path: paints the newest requested frame; stale draws drop out. */
    const paintCanvas = (url: string): void => {
      if (context2d === null || canvas === null) return
      const myToken = ++drawToken
      pinned = url
      void loadFrame(url, true).then((frame) => {
        if (pinned === url) pinned = undefined
        if (disposed || frame === undefined || myToken !== drawToken) return
        if (lastDrawnUrl === url) return
        lastDrawnUrl = url
        // Resizing clears the canvas, so size only when it actually differs.
        if (canvas.width !== frame.width || canvas.height !== frame.height) {
          canvas.width = frame.width
          canvas.height = frame.height
        } else {
          context2d.clearRect(0, 0, canvas.width, canvas.height)
        }
        context2d.drawImage(frame.source as CanvasImageSource, 0, 0)
      }).catch(() => { if (pinned === url) pinned = undefined /* keep last frame */ })
    }

    const show = (trackId: string, index: number): void => {
      const def = config.tracks[trackId]
      const url = def?.frames[index]
      if (url === undefined) return
      prefetchAhead(trackId, index)
      if (img !== null) {
        if (img.getAttribute('src') !== url) img.src = url
        return
      }
      paintCanvas(url)
    }

    const schedule = (ms: number): void => {
      if (disposed) return
      timer = setTimeout(tick, ms)
    }

    function tick(): void {
      if (disposed) return
      const def = config.tracks[track]
      if (def === undefined || def.frames.length === 0) return
      lastAdvance = Date.now()
      const next = frameIndex + 1
      if (next < def.frames.length) {
        frameIndex = next
        show(track, frameIndex)
        schedule(def.durations[frameIndex] ?? 200)
        return
      }
      if (def.loop) {
        frameIndex = 0
        show(track, frameIndex)
        schedule(def.durations[frameIndex] ?? 200)
        return
      }
      // Non-loop completion: settle into the fallback — an explicit fallback to
      // a real track wins, except when it points back at the manifest idle
      // (that resolves through the skin base idle); anything else lands on
      // the skin base idle. When the settle target is what the phase map
      // plays anyway, release the gameplay override.
      const target = def.fallback !== undefined && config.tracks[def.fallback] !== undefined
        ? (def.fallback === config.phases.idle ? baseIdle : def.fallback)
        : baseIdle
      if (target === trackForPhase(ctx.phase.get())) override = undefined
      play(target)
    }

    function play(trackId: string): void {
      if (disposed) return
      if (config.tracks[trackId] === undefined) trackId = baseIdle
      if (timer !== undefined) clearTimeout(timer)
      track = trackId
      frameIndex = 0
      lastAdvance = Date.now()
      show(track, frameIndex)
      if (reducedMotion) return
      const def = config.tracks[track]!
      schedule(def.durations[0] ?? 200)
    }

    const unsubscribe = ctx.phase.subscribe((phase) => {
      if (override !== undefined) return
      const target = trackForPhase(phase)
      if (target !== track) play(target)
    })

    // Watchdog: a throttled-away timer (background tab) leaves the chain
    // dead; re-kick when a looping track has not advanced on schedule.
    if (!reducedMotion) {
      watchdog = setInterval(() => {
        if (disposed) return
        const def = config.tracks[track]
        if (def === undefined || !def.loop) return
        const expected = (def.durations[frameIndex] ?? 200) + WATCHDOG_MS
        if (Date.now() - lastAdvance > expected) tick()
      }, WATCHDOG_MS)
    }

    play(track)

    let disposedOnce = false
    const dispose = (): void => {
      if (disposedOnce) return
      disposedOnce = true
      disposed = true
      unsubscribe()
      if (timer !== undefined) clearTimeout(timer)
      if (watchdog !== undefined) clearInterval(watchdog)
      // Release every retained bitmap and drain the pool. Queued-but-unstarted
      // frames resolve as no-ops (the gate skips decodeFrame once disposed), and
      // a decode that lands after this loop is closed by the resolution guard
      // above, so teardown leaves nothing pending and nothing retained.
      for (const queued of frameQueue.splice(0)) queued.release()
      for (const entry of decoding.values()) releaseFrame(entry.frame)
      decoding.clear()
      retainedBytes = 0
      canvas?.remove()
      img?.remove()
    }
    ctx.onCleanup(dispose)

    return {
      dispose,
      setState(next: string | undefined): void {
        if (disposed) return
        if (next === undefined) {
          override = undefined
          const target = trackForPhase(ctx.phase.get())
          if (target !== track) play(target)
          return
        }
        if (config.tracks[next] === undefined) return
        override = next
        if (next !== track) play(next)
      },
      setIdleTrack(next: string | undefined): void {
        if (disposed) return
        if (next === undefined || (config.tracks[next] !== undefined && config.tracks[next]!.loop)) {
          baseIdle = next ?? config.phases.idle
        }
        // A skin only owns the resting look: re-resolve only when no
        // gameplay override is active (active overrides end into baseIdle).
        if (override === undefined) {
          const target = trackForPhase(ctx.phase.get())
          if (target !== track) play(target)
        }
      },
      currentTrack(): string {
        return track
      },
    }
  },
}
