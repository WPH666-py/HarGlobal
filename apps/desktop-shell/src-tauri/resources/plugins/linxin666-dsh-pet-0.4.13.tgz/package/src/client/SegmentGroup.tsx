/**
 * The family's segmented control: a quiet track whose options share one
 * highlight that slides to the pressed option, instead of each option fading
 * its own background out and the next one in. The settings fields' small
 * choices and the Web Extensions TAB strip both render through it, so the two
 * read as one control.
 *
 * The caller builds the option buttons and marks the pressed one with
 * `data-active`; the group measures that button after every render and writes
 * its box as four custom properties, and the stylesheet draws the highlight
 * there (`.segmentGroup[data-pill]::before`). Attribute and first placement
 * land in the same task, so the highlight appears in place and only later
 * changes slide. A ResizeObserver re-measures when the group or an option
 * changes size: a longer locale, a font arriving, a container growing, a
 * strip wrapping onto a second line.
 */

import { Children, useLayoutEffect, useRef, type HTMLAttributes, type ReactNode } from 'react'
import css from './settings-card.module.css'

/** The attribute marking a group whose highlight has been placed. */
const PILL_ATTR = 'data-pill'
/** The pressed option, relative to the group. */
const ACTIVE_SELECTOR = ':scope > [data-active]'
const PILL_PROPERTIES = ['--segment-pill-x', '--segment-pill-y', '--segment-pill-w', '--segment-pill-h'] as const

/** Props of {@link SegmentGroup}: the track's own attributes and the option buttons. */
export interface SegmentGroupProps extends HTMLAttributes<HTMLDivElement> {
  /** The option buttons; the pressed one carries `data-active`. */
  children: ReactNode
}

/**
 * Write the highlight's box from the pressed option's box, or take the
 * highlight off when nothing is pressed or the group has no layout yet.
 * The two boxes are read in viewport pixels and turned back into the group's
 * own CSS pixels, so a dialog that opens through a scale transform still
 * lands the highlight on its option.
 */
function placePill(group: HTMLElement): void {
  const item = group.querySelector<HTMLElement>(ACTIVE_SELECTOR)
  const box = group.getBoundingClientRect()
  if (item === null || group.offsetWidth === 0 || box.width === 0) {
    group.removeAttribute(PILL_ATTR)
    for (const property of PILL_PROPERTIES) group.style.removeProperty(property)
    return
  }
  const scale = box.width / group.offsetWidth
  const itemBox = item.getBoundingClientRect()
  const values = [
    (itemBox.left - box.left) / scale - group.clientLeft,
    (itemBox.top - box.top) / scale - group.clientTop,
    itemBox.width / scale,
    itemBox.height / scale,
  ]
  values.forEach((value, index) => {
    group.style.setProperty(PILL_PROPERTIES[index], `${Math.round(value * 100) / 100}px`)
  })
  if (!group.hasAttribute(PILL_ATTR)) group.setAttribute(PILL_ATTR, '')
}

/**
 * Render a segmented track around the caller's option buttons.
 * @param props - the track's attributes (role, accessible name, key handler) and its options.
 * @returns the track.
 */
export function SegmentGroup(props: SegmentGroupProps): ReactNode {
  const { children, className, ...rest } = props
  const group = useRef<HTMLDivElement | null>(null)
  const count = Children.count(children)

  // Placed before the frame is painted, after every render: a press moves the
  // pressed mark and the highlight follows it in the same frame.
  useLayoutEffect(() => {
    if (group.current !== null) placePill(group.current)
  })

  useLayoutEffect(() => {
    const element = group.current
    if (element === null || typeof ResizeObserver === 'undefined') return undefined
    const observer = new ResizeObserver(() => { placePill(element) })
    observer.observe(element)
    for (const item of Array.from(element.children)) observer.observe(item)
    return () => { observer.disconnect() }
  }, [count])

  return (
    <div {...rest} ref={group} className={className === undefined ? css.segmentGroup : `${css.segmentGroup} ${className}`}>
      {children}
    </div>
  )
}
