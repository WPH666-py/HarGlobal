import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'

const css = readFileSync(new URL('./pet.module.css', import.meta.url), 'utf8')
const settingsCss = readFileSync(new URL('./settings-section.module.css', import.meta.url), 'utf8')

describe('pet settings section css', () => {
  it('carries no leftover registry diagnostics block after its removal', () => {
    expect(settingsCss).not.toContain('.diagnostics')
    expect(settingsCss).toContain('.sectionList')
  })
})

describe('pet bubble typography (#1549)', () => {
  it('scales the bubble text and padding from the sprite-supplied variable', () => {
    const bubble = css.match(/\.bubble\s*\{([^}]*)\}/)?.[1] ?? ''
    expect(bubble).toContain('font-size: calc(12px * var(--pet-bubble-scale, 1))')
    expect(bubble).toContain('padding: calc(4px * var(--pet-bubble-scale, 1)) calc(10px * var(--pet-bubble-scale, 1))')
    expect(bubble).not.toContain('font-size: 12px')
  })

  it('keeps the status bubble width in proportion with its text', () => {
    const status = css.match(/\.bubbleStatus\s*\{([^}]*)\}/)?.[1] ?? ''
    expect(status).toContain('max-width: min(calc(280px * var(--pet-bubble-scale, 1)), calc(100vw - 24px))')
  })
})

describe('pet floating surfaces (issue #17)', () => {
  it('keeps backdrop-filter off every surface that rides the sprite', () => {
    // A blurred fixed layer makes the region behind it re-composite whenever
    // the sprite animates or roams, and the blur runs on the CPU path under
    // software compositing and power saving. Both the status bubble and the
    // hover panel are 90%+ opaque, so the filter was invisible work. Comments
    // are stripped first: the rules explain WHY the filter is gone.
    const declared = css.replace(/\/\*[\s\S]*?\*\//g, '')
    expect(declared).not.toContain('backdrop-filter')
  })
})

describe('pet hover panel css', () => {
  it('anchors the panel below the pet', () => {
    const panel = css.match(/\.panel\s*\{([^}]*)\}/)?.[1] ?? ''
    expect(panel).toContain('top: 100%')
    expect(panel).toContain('margin-top: 8px')
    expect(panel).not.toContain('right: 100%')
  })

  it('extends the hover bridge upward across the panel gap', () => {
    const bridge = css.match(/\.panel::after\s*\{([^}]*)\}/)?.[1] ?? ''
    expect(bridge).toContain('bottom: 100%')
    expect(bridge).toContain('height: 14px')
  })

  it('keeps the whisper on the shared bubble glass for a unified palette', () => {
    const whisper = css.match(/\.bubbleWhisper\s*\{([^}]*)\}/)?.[1] ?? ''
    // Unified palette: the whisper inherits background/border/shadow/color
    // from .bubble/.bubbleStatus, so a whispering bubble and a status bubble
    // stacked side by side share the same DeepSeek-blue glass; only the mood
    // (quotes, letter-spacing, entrance) is overridden.
    expect(whisper).not.toContain('background')
    expect(whisper).not.toContain('border')
    expect(whisper).not.toContain('box-shadow')
    expect(whisper).not.toContain('color')
    expect(whisper).toContain('animation: pet-whisper-in')
    expect(whisper).not.toContain('font-style: italic')
    expect(whisper).not.toContain('pointer-events')
    expect(whisper).not.toContain('position:')
    expect(css).toContain('@keyframes pet-whisper-in')
    // The mood overrides must be declared after .bubbleStatus to win the cascade.
    expect(css.indexOf('.bubbleWhisper {')).toBeGreaterThan(css.indexOf('.bubbleStatus {'))
  })

  it('gives the panel and status bubbles entrance animations', () => {
    expect(css).toContain('@keyframes pet-panel-in')
    expect(css).toContain('@keyframes pet-bubble-in')
    const panel = css.match(/\.panel\s*\{([^}]*)\}/)?.[1] ?? ''
    expect(panel).toContain('animation: pet-panel-in')
  })

  it('can place the panel above and bridge the lower gap', () => {
    const panel = css.match(/\.panelAbove\s*\{([^}]*)\}/)?.[1] ?? ''
    expect(panel).toContain('bottom: 100%')
    expect(panel).toContain('margin-bottom: 8px')
    const bridge = css.match(/\.panelAbove::after\s*\{([^}]*)\}/)?.[1] ?? ''
    expect(bridge).toContain('top: 100%')
    expect(bridge).toContain('bottom: auto')
  })

  it('isolates the pet float container and sprite on their own compositor layer (issue #1013)', () => {
    const float = css.match(/\.float\s*\{([^}]*)\}/)?.[1] ?? ''
    expect(float).toContain('will-change: transform')
    expect(float).toContain('contain: layout style')

    const sprite = css.match(/\.sprite\s*\{([^}]*)\}/)?.[1] ?? ''
    expect(sprite).toContain('contain: paint')
  })
})
