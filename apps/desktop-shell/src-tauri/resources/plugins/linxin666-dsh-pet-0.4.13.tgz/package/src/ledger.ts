/**
 * Pet affinity economy (ledger) — composes the pure affinity and treats
 * modules with the cooldown/dedup bookkeeping and emits updated persistence
 * snapshots, marking dirty so the owning facade decides when to flush. Read
 * paths (view) no longer settle the economy; settlements happen on explicit
 * economic events: completed-turn rewards (official or legacy) and feeds.
 * @module @linxin666/dsh-pet/ledger
 */

import {
  applyInteraction,
  affinityViewOf,
  applyTurnReward,
  defaultAffinityConfig,
  type AffinityConfig,
  type AffinityRankName,
  type PetAffinityView,
  type PetInteraction,
} from './affinity.ts'
import {
  consumeTreat,
  defaultTreatConfig,
  settleTreatGrants,
  type TreatConfig,
} from './treats.ts'
import { RemarkPicker, type PetRemarks } from './remarks.ts'
import type { PetDisplayConfig, PetPersist } from './persist.ts'
import type { PetGameplayState } from './gameplay.ts'

/** Tuning overrides for the affinity economy. */
export interface LedgerConfig {
  affinity?: Partial<AffinityConfig>
  treats?: Partial<TreatConfig>
  /** Per-pet remark pools for the selected pet (custom slots override built-ins). */
  remarks?: PetRemarks
  /** Voice-pack fallback remark pools (global or pet voice pack). */
  voiceRemarks?: PetRemarks
  /** Display-only rank ladder for the selected pet (voice.json panel.ranks). */
  rankLadder?: readonly AffinityRankName[]
}

/** Result of one ledger interaction (the shape the pet RPC returns). */
export interface LedgerInteractionResult {
  /** Reaction copy bubble. */
  reaction: string
  /** Points gained (0 when inside the cooldown). */
  delta: number
  /** Full affinity snapshot (same shape as the state view). */
  affinity: PetAffinityView
}

/**
 * Holds the current persistence snapshot and all economy bookkeeping. Every
 * mutating call flags takeDirty so the facade persists exactly once per
 * batch of changes; read methods (snapshot, affinityView) never write.
 */
export class PetLedger {
  private readonly affinityConfig: AffinityConfig
  private readonly treatConfig: TreatConfig
  /** Round-robin reaction picker; rebuilt when the selected pet changes. */
  private picker: RemarkPicker
  /** Declared rank ladder; undefined keeps the built-in whale ladder. */
  private rankLadder: readonly AffinityRankName[] | undefined
  private current: PetPersist
  /** Completed turns already rewarded, per session (turn numbers are per-session). */
  private rewardedTurns = new Map<string, number>()
  private lastLegacyTurnRewardAt = 0
  private dirty = false

  constructor(persist: PetPersist, config: LedgerConfig = {}) {
    this.affinityConfig = { ...defaultAffinityConfig, ...(config.affinity ?? {}) }
    this.treatConfig = { ...defaultTreatConfig, ...(config.treats ?? {}) }
    this.picker = new RemarkPicker(config.remarks, config.voiceRemarks)
    this.rankLadder = config.rankLadder
    this.current = persist
  }

  /** Affinity cooldown/rank tuning (read-only). */
  get affinity(): AffinityConfig {
    return this.affinityConfig
  }

  /** The current persistence snapshot (trade a copy when mutating). */
  get snapshot(): PetPersist {
    return this.current
  }

  /** Stock cap reported to clients. */
  get treatMax(): number {
    return this.treatConfig.maxTreats
  }

  /** Consume the pending-write flag if any mutation occurred. */
  takeDirty(): boolean {
    const was = this.dirty
    this.dirty = false
    return was
  }

  /**
   * Drop a session's rewarded-turn bookkeeping once that session is disposed,
   * so the per-session map does not grow without bound.
   */
  forgetSession(sessionId: string): void {
    this.rewardedTurns.delete(sessionId)
  }

  /** Replace the display block (clamping stays a caller concern). */
  setDisplay(display: PetDisplayConfig): void {
    this.current = { ...this.current, display }
    this.dirty = true
  }

  /** Replace the selected pet id (validation stays a caller concern). */
  setPetId(petId: string): void {
    if (this.current.petId === petId) return
    this.current = { ...this.current, petId }
    this.dirty = true
  }

  /** Replace one pet's gameplay state (validation/clamping stays a caller concern). */
  setGameplay(petId: string, gameplay: PetGameplayState): void {
    this.current = { ...this.current, gameplay: { ...this.current.gameplay, [petId]: gameplay } }
    this.dirty = true
  }

  /** Replace one pet's display name (validation stays a caller concern). */
  setPetName(petId: string, name: string): void {
    this.current = { ...this.current, names: { ...this.current.names, [petId]: name } }
    this.dirty = true
  }

  /**
   * Select one pet's frames2d skin; `undefined` clears the choice back to the
   * pet's default look. Manifest validation stays a caller concern, exactly
   * like setPetName's length check.
   */
  setPetSkin(petId: string, skinId: string | undefined): void {
    const skins = this.current.skins
    if (skinId === undefined) {
      if (skins[petId] === undefined) return
      const next = { ...skins }
      delete next[petId]
      this.current = { ...this.current, skins: next }
    } else {
      if (skins[petId] === skinId) return
      this.current = { ...this.current, skins: { ...skins, [petId]: skinId } }
    }
    this.dirty = true
  }

  /** The persisted skin id for one pet (undefined = the pet's default look). */
  petSkin(petId: string): string | undefined {
    return this.current.skins[petId]
  }

  /**
   * Swap the reaction pools to another pet's custom remarks (called on pet
   * selection). Slots the pet does not declare fall back to voice packs or built-ins.
   */
  setRemarks(remarks?: PetRemarks, voiceRemarks?: PetRemarks): void {
    this.picker = new RemarkPicker(remarks, voiceRemarks)
  }

  /**
   * Swap the display-only rank ladder to the selected pet's declared one
   * (called on pet selection). Undefined restores the built-in ladder.
   */
  setRankLadder(ladder?: readonly AffinityRankName[]): void {
    this.rankLadder = ladder
  }

  /**
   * Settle the treat economy (work + time output since the last settlement).
   * A zero-gain first settlement still starts the time clock (anchor write),
   * which is how the time output can ever accrue. Returns true when
   * the in-memory ledger changed and should be persisted.
   */
  settleTreats(nowMs: number): boolean {
    const settlement = settleTreatGrants(
      this.current.treats,
      this.current.affinity.turns,
      nowMs,
      this.treatConfig,
    )
    if (settlement.ledger === this.current.treats) return false
    this.current = { ...this.current, treats: settlement.ledger }
    this.dirty = true
    return true
  }

  /**
   * Grant gameplay treats into the shared stock (capped by the treat cap).
   * This is the unified gameplay currency (wallet removed): work rewards,
   * passive income and lottery prizes land here so one balance feeds the
   * shop and the feeding economy. Returns true when the snapshot changed.
   */
  grantTreats(amount: number): boolean {
    if (amount <= 0) return false
    const capped = Math.min(this.treatConfig.maxTreats, this.current.treats.treats + amount)
    if (capped === this.current.treats.treats) return false
    this.current = { ...this.current, treats: { ...this.current.treats, treats: capped } }
    this.dirty = true
    return true
  }

  /** Spend gameplay treats from the shared stock; refuses when unaffordable. */
  spendTreats(amount: number): { ok: boolean } {
    const stock = this.current.treats.treats
    if (amount <= 0 || stock < amount) return { ok: false }
    this.current = { ...this.current, treats: { ...this.current.treats, treats: stock - amount } }
    this.dirty = true
    return { ok: true }
  }

  /**
   * Award the completed-turn reward once per session+turn (idempotent) and
   * run the treat settlement that work output feeds. Returns true when the
   * snapshot changed.
   */
  rewardTurn(sessionId: string, turn: number, nowMs: number): boolean {
    const last = this.rewardedTurns.get(sessionId) ?? 0
    if (turn <= last) return false
    this.rewardedTurns.set(sessionId, turn)
    let changed = this.applyTurnReward()
    if (this.settleTreats(nowMs)) changed = true
    return changed
  }

  /** Preserve turn rewards for installations that only emit legacy activity. */
  rewardLegacyTurn(nowMs: number): boolean {
    // A legacy done snapshot may repeat during the celebration window.
    if (nowMs - this.lastLegacyTurnRewardAt < 5_000) return false
    this.lastLegacyTurnRewardAt = nowMs
    let changed = this.applyTurnReward()
    if (this.settleTreats(nowMs)) changed = true
    return changed
  }

  private applyTurnReward(): boolean {
    this.current = {
      ...this.current,
      affinity: applyTurnReward(this.current.affinity, this.affinityConfig),
    }
    this.dirty = true
    return true
  }

  /**
   * Pet or feed the pet. Feeding settles first, then gates on the feed
   * cooldown before spending stock — a feed inside the cooldown must not burn
   * a treat for nothing.
   */
  interact(kind: PetInteraction, nowMs: number): LedgerInteractionResult {
    if (kind === 'feed') this.settleTreats(nowMs)
    const before = this.current.affinity
    const outcome = applyInteraction(before, kind, nowMs, this.affinityConfig)
    // Reactions come from the picker pools (custom per-pet slots override
    // the built-in library per slot); outcome.reaction stays the fallback
    // copy for direct applyInteraction callers.
    if (kind === 'feed' && !outcome.accepted) {
      this.current = { ...this.current, affinity: outcome.affinity }
      this.dirty = true
      return {
        reaction: this.picker.pickAt('feedCooldown', before.feedRejects),
        delta: 0,
        affinity: this.affinityView(nowMs),
      }
    }
    if (kind === 'feed') {
      const consume = consumeTreat(this.current.treats)
      if (!consume.ok) {
        return {
          reaction: this.picker.pick('noTreats'),
          delta: 0,
          affinity: this.affinityView(nowMs),
        }
      }
      this.current = { ...this.current, treats: consume.ledger }
      this.dirty = true
    }
    this.current = { ...this.current, affinity: outcome.affinity }
    this.dirty = true
    const count = kind === 'pet'
      ? outcome.accepted ? before.pets : before.petRejects
      : before.feeds
    return {
      reaction: this.picker.pickAt(outcome.accepted ? kind : 'petCooldown', count),
      delta: outcome.delta,
      affinity: this.affinityView(nowMs),
    }
  }

  /** Current affinity view for the RPC snapshot. */
  affinityView(nowMs: number): PetAffinityView {
    return affinityViewOf(this.current.affinity, nowMs, this.affinityConfig, this.rankLadder)
  }
}
