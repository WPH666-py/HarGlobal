export default {
  "schema": "agent-mix-tooling/1",
  "upstream": "Qwen Code",
  "version": "0.27.4",
  "contractSource": "chunks\\acpAgent-DYVOMNZP.js sha256:76c9d14ebda816d2",
  "tools": {
    "aliased": [
      {
        "upstream": "agent",
        "harness": "subagent",
        "params": [
          "description",
          "prompt",
          "run_in_background"
        ]
      },
      {
        "upstream": "artifact",
        "harness": "artifact_save"
      },
      {
        "upstream": "ask_user_question",
        "harness": "ask_user_question",
        "params": [
          "questions",
          "metadata"
        ]
      },
      {
        "upstream": "create_sub_session",
        "harness": "subagent"
      },
      {
        "upstream": "cron_delete",
        "harness": "schedule_delete",
        "params": [
          "id"
        ]
      },
      {
        "upstream": "cron_list",
        "harness": "schedule_list"
      },
      {
        "upstream": "display_image",
        "harness": "show_image"
      },
      {
        "upstream": "edit",
        "harness": "edit",
        "params": [
          "file_path",
          "old_string",
          "new_string",
          "replace_all"
        ]
      },
      {
        "upstream": "exec",
        "harness": "pwsh",
        "renames": [
          "is_background->run_in_background"
        ]
      },
      {
        "upstream": "exit_plan_mode",
        "harness": "exit_plan_mode",
        "params": [
          "plan",
          "originalRequest",
          "researchSummary"
        ]
      },
      {
        "upstream": "get_goal",
        "harness": "get_goal"
      },
      {
        "upstream": "glob",
        "harness": "ops_glob",
        "params": [
          "pattern",
          "path"
        ]
      },
      {
        "upstream": "grep_search",
        "harness": "ops_grep"
      },
      {
        "upstream": "list_agents",
        "harness": "list_agents"
      },
      {
        "upstream": "list_directory",
        "harness": "ops_glob",
        "params": [
          "path",
          "description"
        ],
        "note": "List with a single-level glob."
      },
      {
        "upstream": "loop_wakeup",
        "harness": "schedule_create",
        "params": [
          "delaySeconds",
          "prompt",
          "reason"
        ],
        "renames": [
          "delay_seconds->after_seconds"
        ]
      },
      {
        "upstream": "monitor",
        "harness": "job_output",
        "params": [
          "command",
          "idle_timeout_ms",
          "max_events",
          "description"
        ]
      },
      {
        "upstream": "omni_transcribe_audio",
        "harness": "study_audio",
        "note": "Transcription lane exists via the study audio API."
      },
      {
        "upstream": "propose_goal",
        "harness": "create_goal"
      },
      {
        "upstream": "read_file",
        "harness": "ops_read_files",
        "params": [
          "file_path",
          "offset",
          "limit"
        ],
        "renames": [
          "file_path->path"
        ]
      },
      {
        "upstream": "read_mcp_resource",
        "harness": "read_mcp_resource"
      },
      {
        "upstream": "record_artifact",
        "harness": "artifact_save"
      },
      {
        "upstream": "run_shell_command",
        "harness": "pwsh",
        "params": [
          "command",
          "timeout",
          "description",
          "is_background"
        ],
        "renames": [
          "is_background->run_in_background",
          "timeout->timeoutMs"
        ]
      },
      {
        "upstream": "send_message",
        "harness": "send_message",
        "params": [
          "to",
          "task_id",
          "message"
        ]
      },
      {
        "upstream": "skill",
        "harness": "skill",
        "params": [
          "__unsupported"
        ]
      },
      {
        "upstream": "task_stop",
        "harness": "job_kill",
        "renames": [
          "task_id->job_id"
        ]
      },
      {
        "upstream": "todo_write",
        "harness": "todo_write",
        "params": [
          "todos"
        ]
      },
      {
        "upstream": "tool_search",
        "harness": "ops_discover_tools"
      },
      {
        "upstream": "update_goal",
        "harness": "update_goal"
      },
      {
        "upstream": "web_fetch",
        "harness": "web_fetch",
        "params": [
          "url",
          "prompt",
          "format"
        ],
        "renames": [
          "prompt->query"
        ]
      },
      {
        "upstream": "web_search",
        "harness": "web_search"
      },
      {
        "upstream": "workflow",
        "harness": "workflow",
        "params": [
          "script",
          "args",
          "run_in_background"
        ]
      },
      {
        "upstream": "write_file",
        "harness": "write",
        "params": [
          "file_path",
          "content"
        ],
        "renames": [
          "path->file_path"
        ]
      },
      {
        "upstream": "zoom_image",
        "harness": "read_image",
        "note": "Region zoom needs an annotated crop instead."
      }
    ],
    "emulated": [
      {
        "upstream": "autofix_pr",
        "harness": "pwsh",
        "note": "Drive gh through the shell."
      },
      {
        "upstream": "cron_create",
        "harness": "schedule_create",
        "params": [
          "cron",
          "prompt",
          "recurring",
          "durable",
          "timezone",
          "gate"
        ],
        "note": "Session-scoped reminders, not OS cron."
      },
      {
        "upstream": "enter_plan_mode",
        "harness": "todo_write",
        "params": [
          "userRequested"
        ],
        "note": "Plan mode is a session mode in Harness, not a tool call."
      },
      {
        "upstream": "enter_worktree",
        "harness": "pwsh",
        "note": "Emulate with git worktree."
      },
      {
        "upstream": "exit_worktree",
        "harness": "pwsh"
      },
      {
        "upstream": "manage_memory",
        "harness": "knowledge_write_node"
      },
      {
        "upstream": "omni_caption_audio",
        "note": "Not mapped;"
      },
      {
        "upstream": "omni_caption_image",
        "harness": "modlens_read_image"
      },
      {
        "upstream": "omni_clip_audio",
        "note": "Not mapped;"
      },
      {
        "upstream": "omni_clip_image",
        "note": "Not mapped;"
      },
      {
        "upstream": "omni_clip_video",
        "note": "Not mapped;"
      },
      {
        "upstream": "omni_convert_image",
        "note": "Not mapped;"
      },
      {
        "upstream": "omni_downsample_audio",
        "note": "Not mapped;"
      },
      {
        "upstream": "omni_downsample_image",
        "note": "Not mapped;"
      },
      {
        "upstream": "omni_downscale_video",
        "note": "Not mapped;"
      },
      {
        "upstream": "omni_extract_audio",
        "note": "Not mapped;"
      },
      {
        "upstream": "omni_extract_keyframes",
        "note": "Not mapped;"
      },
      {
        "upstream": "omni_ocr_image",
        "harness": "modlens_read_image",
        "note": "OCR comes from the vision bridge."
      },
      {
        "upstream": "omni_recall_media_memory",
        "note": "Not mapped;"
      },
      {
        "upstream": "omni_understand_video_segments",
        "note": "Not mapped;"
      },
      {
        "upstream": "record_source",
        "harness": "artifact_save",
        "note": "Record the input as a provenance source."
      },
      {
        "upstream": "report_findings",
        "harness": "todo_write",
        "note": "No findings channel;"
      },
      {
        "upstream": "save_memory",
        "harness": "knowledge_write_node",
        "note": "Durable notes go to the knowledge base instead."
      },
      {
        "upstream": "search_memory",
        "harness": "knowledge_read"
      },
      {
        "upstream": "task_create",
        "harness": "todo_write",
        "params": [
          "subject",
          "description",
          "activeForm",
          "metadata"
        ],
        "note": "Task board collapses into the todo list."
      },
      {
        "upstream": "task_list",
        "harness": "todo_write",
        "params": [
          "status",
          "owner",
          "blockedBy"
        ]
      },
      {
        "upstream": "task_update",
        "harness": "todo_write",
        "params": [
          "taskId",
          "status",
          "owner",
          "subject",
          "description",
          "activeForm",
          "metadata",
          "addBlocks",
          "addBlockedBy"
        ]
      }
    ],
    "missing": [
      {
        "upstream": "advisor",
        "note": "no native equivalent"
      },
      {
        "upstream": "image_gen",
        "note": "no native equivalent"
      },
      {
        "upstream": "lsp",
        "note": "No language-server integration."
      },
      {
        "upstream": "notebook_edit",
        "note": "No notebook-aware editor;"
      },
      {
        "upstream": "request_shutdown",
        "note": "no native equivalent"
      },
      {
        "upstream": "structured_output",
        "note": "no native equivalent"
      },
      {
        "upstream": "team_create",
        "note": "No team-scoped agents."
      },
      {
        "upstream": "team_delete",
        "note": "no native equivalent"
      },
      {
        "upstream": "team_plan_approval",
        "note": "no native equivalent"
      },
      {
        "upstream": "tool_call",
        "note": "Meta tool with no Harness equivalent."
      }
    ]
  },
  "counts": {
    "aliased": 34,
    "emulated": 27,
    "missing": 10,
    "platformTools": 28
  }
}
