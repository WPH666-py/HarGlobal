export default {
  "schema": "agent-mix-tooling/1",
  "upstream": "Kimi Code",
  "version": "2.6.2",
  "contractSource": "unknown sha256:",
  "tools": {
    "aliased": [
      {
        "upstream": "Bash",
        "harness": "pwsh",
        "renames": [
          "timeout->timeoutMs"
        ]
      },
      {
        "upstream": "Glob",
        "harness": "ops_glob"
      },
      {
        "upstream": "Grep",
        "harness": "ops_grep",
        "renames": [
          "output_mode->outputMode"
        ]
      },
      {
        "upstream": "Read",
        "harness": "ops_read_files",
        "renames": [
          "file_path->path"
        ]
      },
      {
        "upstream": "Write",
        "harness": "write"
      },
      {
        "upstream": "Skill",
        "harness": "skill"
      },
      {
        "upstream": "ExitPlanMode",
        "harness": "exit_plan_mode"
      },
      {
        "upstream": "CreateGoal",
        "harness": "create_goal"
      },
      {
        "upstream": "GetGoal",
        "harness": "get_goal"
      },
      {
        "upstream": "UpdateGoal",
        "harness": "update_goal"
      },
      {
        "upstream": "TowerMission",
        "harness": "subagent",
        "note": "One mission maps to one subagent brief."
      },
      {
        "upstream": "TowerSend",
        "harness": "send_message"
      },
      {
        "upstream": "TaskOutput",
        "harness": "job_output",
        "renames": [
          "task_id->job_id"
        ]
      },
      {
        "upstream": "TaskStop",
        "harness": "job_kill",
        "renames": [
          "shell_id->job_id",
          "task_id->job_id"
        ]
      },
      {
        "upstream": "WaitFor",
        "harness": "job_output",
        "note": "Poll the background job instead of blocking a turn."
      },
      {
        "upstream": "CronDelete",
        "harness": "schedule_delete"
      },
      {
        "upstream": "CronList",
        "harness": "schedule_list"
      },
      {
        "upstream": "WebSearch",
        "harness": "web_search"
      },
      {
        "upstream": "Edit",
        "harness": "edit"
      },
      {
        "upstream": "FetchURL",
        "harness": "web_fetch",
        "renames": [
          "prompt->query"
        ]
      }
    ],
    "emulated": [
      {
        "upstream": "SetGoalBudget",
        "harness": "update_goal",
        "note": "Token budgets are not a goal attribute here."
      },
      {
        "upstream": "TowerComplete",
        "harness": "todo_write"
      },
      {
        "upstream": "TowerFinding",
        "harness": "todo_write"
      },
      {
        "upstream": "TowerMerge",
        "harness": "pwsh",
        "note": "Merge worktrees with git through the shell."
      },
      {
        "upstream": "TowerPlan",
        "harness": "todo_write"
      },
      {
        "upstream": "TowerRebase",
        "harness": "pwsh"
      },
      {
        "upstream": "TowerReview",
        "harness": "subagent",
        "note": "A review pass is a separate subagent, not a Tower role."
      },
      {
        "upstream": "TowerStatus",
        "harness": "list_agents"
      },
      {
        "upstream": "TowerTeardown",
        "harness": "pwsh"
      },
      {
        "upstream": "TaskList",
        "harness": "todo_write",
        "note": "Task board collapses into the todo list."
      },
      {
        "upstream": "CronCreate",
        "harness": "schedule_create",
        "note": "Harness schedules are session-local reminders, not OS cron."
      }
    ],
    "missing": [
      {
        "upstream": "TowerInbox",
        "note": "No mailbox between agents;"
      },
      {
        "upstream": "TowerInit",
        "note": "Tower coordinates agents through git worktrees;"
      }
    ]
  },
  "counts": {
    "aliased": 20,
    "emulated": 11,
    "missing": 2,
    "platformTools": 0
  }
}
