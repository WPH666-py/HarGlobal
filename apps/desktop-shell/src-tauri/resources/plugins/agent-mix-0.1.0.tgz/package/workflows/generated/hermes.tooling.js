export default {
  "schema": "agent-mix-tooling/1",
  "upstream": "Hermes",
  "version": "0.19.0",
  "contractSource": ".pyscan.hermes.ir.json.json sha256:bba835200082e208",
  "tools": {
    "aliased": [
      {
        "upstream": "delegate_task",
        "harness": "subagent",
        "params": [
          "goal",
          "context",
          "tasks",
          "role",
          "background"
        ],
        "renames": [
          "goal->prompt",
          "context->prompt"
        ]
      },
      {
        "upstream": "memory",
        "harness": "knowledge_write_node",
        "params": [
          "action",
          "target",
          "content",
          "old_text",
          "operations"
        ],
        "renames": [
          "content->body"
        ]
      },
      {
        "upstream": "patch",
        "harness": "edit",
        "params": [
          "mode",
          "path",
          "old_string",
          "new_string",
          "replace_all",
          "patch",
          "cross_profile"
        ],
        "renames": [
          "path->file_path"
        ]
      },
      {
        "upstream": "process",
        "harness": "job_output",
        "params": [
          "action",
          "session_id",
          "data",
          "timeout",
          "offset",
          "limit"
        ],
        "renames": [
          "action->wait",
          "process_id->job_id"
        ],
        "note": "list/poll/kill collapse onto job_output and job_kill."
      },
      {
        "upstream": "read_file",
        "harness": "ops_read_files",
        "params": [
          "path",
          "offset",
          "limit"
        ]
      },
      {
        "upstream": "read_terminal",
        "harness": "job_output",
        "params": [
          "start_line",
          "count"
        ],
        "note": "Read a background job log instead of a GUI tab."
      },
      {
        "upstream": "search_files",
        "harness": "ops_grep",
        "params": [
          "pattern",
          "target",
          "path",
          "file_glob",
          "limit",
          "offset",
          "output_mode",
          "context"
        ]
      },
      {
        "upstream": "session_search",
        "harness": "hindsight_search_knowledge_pages",
        "params": [
          "query",
          "limit",
          "sort",
          "session_id",
          "around_message_id",
          "window",
          "role_filter",
          "profile"
        ]
      },
      {
        "upstream": "skill_view",
        "harness": "skill",
        "params": [
          "name",
          "file_path"
        ]
      },
      {
        "upstream": "todo",
        "harness": "todo_write",
        "params": [
          "todos",
          "merge"
        ]
      },
      {
        "upstream": "vision_analyze",
        "harness": "modlens_read_image",
        "params": [
          "image_url",
          "question"
        ],
        "renames": [
          "image_url->path"
        ]
      },
      {
        "upstream": "web_extract",
        "harness": "web_fetch",
        "params": [
          "urls",
          "char_limit"
        ],
        "renames": [
          "urls->url"
        ],
        "note": "One URL per call."
      },
      {
        "upstream": "web_search",
        "harness": "web_search",
        "params": [
          "query",
          "limit"
        ]
      },
      {
        "upstream": "write_file",
        "harness": "write",
        "params": [
          "path",
          "content",
          "cross_profile"
        ],
        "renames": [
          "path->file_path"
        ]
      }
    ],
    "emulated": [
      {
        "upstream": "skills_list",
        "harness": "ops_discover_tools",
        "params": [
          "category"
        ],
        "note": "Harness lists skills in the session catalog, not through a tool."
      }
    ],
    "missing": [
      {
        "upstream": "browser_back",
        "note": "no native equivalent"
      },
      {
        "upstream": "browser_click",
        "note": "no native equivalent"
      },
      {
        "upstream": "browser_console",
        "note": "no native equivalent"
      },
      {
        "upstream": "browser_dialog",
        "note": "no native equivalent"
      },
      {
        "upstream": "browser_get_images",
        "note": "no native equivalent"
      },
      {
        "upstream": "browser_navigate",
        "note": "No in-process browser;"
      },
      {
        "upstream": "browser_press",
        "note": "no native equivalent"
      },
      {
        "upstream": "browser_scroll",
        "note": "no native equivalent"
      },
      {
        "upstream": "browser_snapshot",
        "note": "no native equivalent"
      },
      {
        "upstream": "browser_type",
        "note": "no native equivalent"
      },
      {
        "upstream": "browser_vision",
        "note": "no native equivalent"
      },
      {
        "upstream": "close_terminal",
        "note": "No GUI terminal tabs to close."
      },
      {
        "upstream": "computer_use",
        "note": "No desktop automation surface."
      },
      {
        "upstream": "ha_call_service",
        "note": "no native equivalent"
      },
      {
        "upstream": "ha_get_state",
        "note": "no native equivalent"
      },
      {
        "upstream": "ha_list_entities",
        "note": "No Home Assistant integration."
      },
      {
        "upstream": "ha_list_services",
        "note": "no native equivalent"
      }
    ]
  },
  "counts": {
    "aliased": 14,
    "emulated": 1,
    "missing": 17,
    "platformTools": 60
  }
}
