/**
 * Shared vocabulary for Agent-Mix workflow packs.
 *
 * A workflow pack is deliberately small and data-only: one identity, one
 * operating protocol, and one optional external-engine manifest. The Host
 * plugin turns it into a scoped persona section and a delegation tool at
 * preset-activation time.
 */

export const COMMON_CONTRACT = `
## Agent-Mix execution contract

These rules apply to every Agent-Mix workflow. A workflow-specific rule wins
only where it is stricter than this contract.

1. **Ground every claim in the workspace.** Read the relevant files, run the
   relevant checks, and distinguish observed facts from assumptions. Never
   invent a file, command result, test outcome, or upstream capability.
2. **Inspect before editing.** Match the repository's existing structure,
   naming, error handling, and test style. Prefer a focused change in the
   right place over a broad rewrite.
3. **Keep the user's work.** Do not revert, reformat, or delete changes you did
   not make unless the task explicitly requires it. Do not run destructive
   commands against data outside the workspace.
4. **Use the smallest capable tool.** Use read/search/edit for precise file
   work, shell only for commands and processes, and delegation only when the
   task is large or independent enough to justify another agent.
5. **Plan multi-step work visibly.** For work that spans several files or
   verification stages, maintain a short todo list and keep it current. Do not
   turn a small fix into ceremony.
6. **Verify before declaring completion.** Run the narrowest meaningful tests,
   type checks, linters, builds, or reproductions. If a check cannot run,
   state exactly why and what remains unverified.
7. **Respect the permission boundary.** If an operation needs authority the
   session does not have, stop and explain the exact operation and reason.
   Never route around a denial through a different tool or an external engine.
8. **External engines are optional accelerators.** If this workflow provides
   \`agent_mix_engine\`, using it runs another coding agent unattended in the
   same workspace. It is a separate process outside DSH's tool-approval and
   sandbox pipeline; never use it to bypass a denial. Inspect its diff and
   verify its claims yourself; its output is evidence to review, not ground
   truth. If the engine is missing, continue with the native tools rather than
   blocking the task.
9. **Ask only user-owned questions.** Use \`ask_user_question\` for product
   choices, credentials, or genuinely ambiguous requirements that inspection
   cannot resolve. Do not ask where code lives or how it currently behaves.
10. **Communicate at the end, not at every step.** Lead with the result, name
    the files changed, name the checks run, and surface remaining risks. Keep
    intermediate narration short.
`.trim()

const ID_PATTERN = /^[a-z0-9][a-z0-9-]*$/

/**
 * Normalize one workflow declaration.
 * @param {object} definition
 * @returns {object}
 */
export function defineWorkflow(definition) {
  const {
    id,
    name,
    shortName = name,
    tagline,
    description,
    repo,
    docs,
    language,
    license,
    sourceKind = 'source',
    rust = false,
    prompt,
    engine,
    tooling,
  } = definition

  if (!ID_PATTERN.test(id ?? '')) {
    throw new Error(`Agent-Mix workflow id must match ${ID_PATTERN}: ${String(id)}`)
  }
  if (!name || !tagline || !description) {
    throw new Error(`Agent-Mix workflow ${id} is missing name, tagline, or description`)
  }
  if (!prompt || prompt.trim().length < 80) {
    throw new Error(`Agent-Mix workflow ${id} needs a substantive prompt`)
  }

  const normalizedEngine = normalizeEngine(id, engine)

  return Object.freeze({
    id,
    name,
    shortName,
    tagline,
    description,
    repo,
    docs,
    language,
    license,
    sourceKind,
    rust,
    engine: normalizedEngine,
    tooling: normalizeTooling(id, tooling),
    prompt: promptWith(tooling, prompt),
  })
}

function normalizeEngine(workflowId, engine) {
  if (engine === undefined || engine === null) {
    return Object.freeze({
      kind: 'native',
      name: 'DeepSeek Harness native tools',
      install: null,
      docs: null,
      note: 'No external engine; this mode runs entirely on the native Harness tool loop.',
    })
  }

  if (engine.kind !== 'cli') {
    throw new Error(`Agent-Mix workflow ${workflowId} has unsupported engine kind ${String(engine.kind)}`)
  }
  if (!Array.isArray(engine.commands) || engine.commands.length === 0) {
    throw new Error(`Agent-Mix workflow ${workflowId} needs at least one engine command`)
  }
  if (!Array.isArray(engine.args)) {
    throw new Error(`Agent-Mix workflow ${workflowId} needs an args array`)
  }
  const promptMode = engine.prompt ?? 'stdin'
  if (promptMode !== 'stdin' && promptMode !== 'arg') {
    throw new Error(`Agent-Mix workflow ${workflowId} prompt mode must be stdin or arg`)
  }
  const timeoutSec = engine.timeoutSec ?? 1800
  if (!Number.isFinite(timeoutSec) || timeoutSec < 30 || timeoutSec > 7200) {
    throw new Error(`Agent-Mix workflow ${workflowId} timeoutSec must be 30..7200`)
  }

  return Object.freeze({
    kind: 'cli',
    name: engine.name ?? engine.commands[0],
    commands: Object.freeze([...engine.commands]),
    args: Object.freeze([...engine.args]),
    prompt: promptMode,
    timeoutSec,
    install: engine.install ?? null,
    docs: engine.docs ?? null,
    note: engine.note ?? '',
  })
}

/**
 * Render a captured upstream tool contract into a prompt section.
 *
 * The section is what makes a workflow more than a costume: it tells the model
 * which real Harness tool stands in for each upstream tool, how the parameters
 * are spelled here, and which upstream capabilities this mode does not have.
 *
 * @param {object|null|undefined} tooling
 */
export function renderTooling(tooling) {
  if (!tooling || typeof tooling !== "object") return ""
  const groups = tooling.tools ?? {}
  const out = []
  out.push("## Upstream tool semantics (" + tooling.upstream + " " + tooling.version + ")")
  out.push("")
  out.push("Captured from " + tooling.contractSource + ". This workflow speaks the upstream tool")
  out.push("vocabulary: call the Harness tool on the right, and keep the upstream parameter habits")
  out.push("described here instead of inventing your own spelling.")
  out.push("")
  const section = (title, entries, render) => {
    if (!Array.isArray(entries) || entries.length === 0) return
    out.push("**" + title + "**")
    for (const entry of entries) out.push(render(entry))
    out.push("")
  }
  section("Direct and aliased", groups.aliased, (e) => {
    let line = "- `" + e.upstream + "` -> `" + (e.harness ?? "native") + "`"
    if (e.params && e.params.length) line += " [" + e.params.join(", ") + "]"
    if (e.renames && e.renames.length) line += " renames: " + e.renames.join(", ")
    if (e.note) line += " - " + e.note
    return line
  })
  section("Emulated with a different shape", groups.emulated, (e) => {
    let line = "- `" + e.upstream + "` -> `" + (e.harness ?? "nearest native tool") + "`"
    if (e.note) line += " - " + e.note
    return line
  })
  section("Not available in this mode", groups.missing, (e) => {
    return "- `" + e.upstream + "` - " + (e.note ?? "no native equivalent")
  })
  if (tooling.modes && Array.isArray(tooling.modes.modes) && tooling.modes.modes.length > 0) {
    const modeAllowlists = tooling.modes
    out.push("**Modes over one shared tool set**")
    out.push("")
    out.push("Upstream: " + modeAllowlists.modes.join(", ") + ".")
    if (modeAllowlists.policyStatement) out.push(modeAllowlists.policyStatement)
    const groups = Object.entries(modeAllowlists.groupToPermission ?? {})
    if (groups.length > 0) {
      out.push("Tool groups map onto permissions as: " + groups.map(([g, p]) => g + " -> " + p).join(", ") + ".")
    }
    out.push("")
    out.push("In this host there is one agent per session, so a mode is a discipline you state and")
    out.push("keep, not a switch you flip: say which mode you are working in, and do not reach for a")
    out.push("capability that mode would not have. When the task changes mode (plan -> build), say so")
    out.push("before the first edit.")
    out.push("")
  }
  out.push("When the capability you want is listed as not available, use the nearest native tool")
  out.push("deliberately and say which one you used. Never describe an unavailable tool call as done.")
  return out.join("\n") + "\n"
}

function promptWith(tooling, prompt) {
  return prompt.trim() + "\n\n" + renderTooling(tooling) + "\n" + COMMON_CONTRACT + "\n"
}

/**
 * Validate a captured tool contract. A malformed descriptor must fail at
 * load time, not render as an empty prompt section that silently weakens the
 * workflow without anyone noticing.
 */
function normalizeTooling(workflowId, tooling) {
  if (tooling === undefined || tooling === null) return null
  if (typeof tooling !== "object") throw new Error(`workflow ${workflowId}: tooling must be an object`)
  if (tooling.schema !== "agent-mix-tooling/1") {
    throw new Error(`workflow ${workflowId}: unknown tooling schema ${String(tooling.schema)}`)
  }
  if (typeof tooling.upstream !== "string" || tooling.upstream.length === 0) {
    throw new Error(`workflow ${workflowId}: tooling.upstream is required`)
  }
  const groups = tooling.tools ?? {}
  for (const key of ["aliased", "emulated", "missing"]) {
    if (groups[key] !== undefined && !Array.isArray(groups[key])) {
      throw new Error(`workflow ${workflowId}: tooling.tools.${key} must be an array`)
    }
  }
  return Object.freeze(tooling)
}
