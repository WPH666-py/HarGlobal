export default {
  "schema": "agent-mix-tooling/1",
  "upstream": "Trae",
  "version": "unknown",
  "contractSource": "unknown sha256:",
  "tools": {
    "aliased": [
      {
        "upstream": "bash",
        "harness": "pwsh",
        "params": [
          "command",
          "restart"
        ],
        "renames": [
          "timeout->timeoutMs"
        ],
        "note": "Registered as bash;"
      },
      {
        "upstream": "str_replace_based_edit_tool",
        "harness": "edit",
        "params": [
          "command",
          "file_text",
          "insert_line",
          "new_str",
          "old_str",
          "path",
          "view_range"
        ],
        "renames": [
          "path->file_path",
          "old_str->old_string",
          "new_str->new_string"
        ]
      }
    ],
    "emulated": [
      {
        "upstream": "ckg",
        "harness": "ops_grep",
        "params": [
          "command",
          "path",
          "identifier",
          "print_body"
        ],
        "note": "Code knowledge graph becomes targeted lexical search."
      },
      {
        "upstream": "json_edit_tool",
        "harness": "edit",
        "params": [
          "operation",
          "file_path",
          "json_path",
          "value",
          "pretty_print"
        ],
        "note": "JSON edits are expressed as text edits;"
      },
      {
        "upstream": "sequentialthinking",
        "harness": "todo_write",
        "params": [
          "thought",
          "next_thought_needed",
          "thought_number",
          "total_thoughts",
          "is_revision",
          "revises_thought",
          "branch_from_thought",
          "branch_id",
          "needs_more_thoughts"
        ],
        "note": "Reasoning steps live in the response and the todo list, not in a tool."
      }
    ],
    "missing": [
      {
        "upstream": "task_done",
        "note": "Internal completion signal;"
      }
    ]
  },
  "counts": {
    "aliased": 2,
    "emulated": 3,
    "missing": 1,
    "platformTools": 0
  }
}
