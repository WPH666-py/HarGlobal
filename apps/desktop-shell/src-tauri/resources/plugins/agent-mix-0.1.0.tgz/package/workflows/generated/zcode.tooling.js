export default {
  "schema": "agent-mix-tooling/1",
  "upstream": "ZCode",
  "version": "unknown",
  "contractSource": "zcode.cjs sha256:",
  "tools": {
    "aliased": [
      {
        "upstream": "websearch",
        "harness": "web_search"
      },
      {
        "upstream": "tool.search",
        "harness": "ops_discover_tools"
      },
      {
        "upstream": "read",
        "harness": "ops_read_files"
      },
      {
        "upstream": "edit",
        "harness": "edit"
      },
      {
        "upstream": "bash",
        "harness": "pwsh",
        "renames": [
          "timeout->timeoutMs"
        ],
        "note": "Registered as bash;"
      },
      {
        "upstream": "webfetch",
        "harness": "web_fetch",
        "renames": [
          "prompt->query"
        ]
      },
      {
        "upstream": "skill",
        "harness": "skill"
      },
      {
        "upstream": "todo.write",
        "harness": "todo_write"
      },
      {
        "upstream": "userInteraction.askQuestion",
        "harness": "ask_user_question"
      },
      {
        "upstream": "agent.message.send",
        "harness": "send_message"
      },
      {
        "upstream": "agent.message.respond",
        "harness": "send_message"
      },
      {
        "upstream": "taskOutput",
        "harness": "job_output",
        "renames": [
          "task_id->job_id"
        ]
      },
      {
        "upstream": "backgroundTask.stop",
        "harness": "job_kill",
        "renames": [
          "task_id->job_id"
        ]
      }
    ],
    "emulated": [
      {
        "upstream": "tool.deferred_call",
        "harness": "ops_discover_tools",
        "note": "No deferred-call registry;"
      },
      {
        "upstream": "node_repl",
        "harness": "pwsh",
        "note": "Node evaluation runs through a shell command."
      },
      {
        "upstream": "subagent",
        "note": "Not mapped;"
      },
      {
        "upstream": "todo.read",
        "harness": "todo_write",
        "note": "The todo list is read by keeping it in context."
      },
      {
        "upstream": "automation.read",
        "harness": "schedule_list",
        "note": "Inspect scheduled reminders instead."
      },
      {
        "upstream": "workflow.submitResult",
        "harness": "todo_write"
      },
      {
        "upstream": "workflow.escalate",
        "harness": "ask_user_question"
      },
      {
        "upstream": "resolveWorkflowQuestion",
        "harness": "ask_user_question"
      },
      {
        "upstream": "createWorkflow",
        "harness": "workflow",
        "note": "ZCode workflows are product objects;"
      },
      {
        "upstream": "saveWorkflow",
        "harness": "workflow"
      },
      {
        "upstream": "evalWorkflowSnippet",
        "harness": "pwsh",
        "note": "Evaluate through the shell, deliberately."
      },
      {
        "upstream": "listWorkflowRuns",
        "harness": "job_list"
      },
      {
        "upstream": "getWorkflowRun",
        "harness": "job_output"
      },
      {
        "upstream": "resumeWorkflowRun",
        "harness": "job_output"
      }
    ],
    "missing": [
      {
        "upstream": "automation.pause",
        "note": "No scheduling automation to pause."
      },
      {
        "upstream": "offpeak.read",
        "note": "Off-peak pricing windows are a provider feature."
      },
      {
        "upstream": "session.context.read",
        "note": "Harness does not expose a context introspection tool."
      },
      {
        "upstream": "listSavedWorkflows",
        "note": "no native equivalent"
      },
      {
        "upstream": "listModels",
        "note": "no native equivalent"
      }
    ]
  },
  "counts": {
    "aliased": 13,
    "emulated": 14,
    "missing": 5,
    "platformTools": 0
  }
}
