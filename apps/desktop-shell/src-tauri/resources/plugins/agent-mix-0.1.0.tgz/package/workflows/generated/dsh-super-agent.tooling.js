export default {
  "schema": "agent-mix-tooling/1",
  "upstream": "DSH SuperAgent",
  "version": "0.0.5",
  "contractSource": "unknown sha256:",
  "tools": {
    "aliased": [
      {
        "upstream": "command-goal",
        "harness": "command-goal",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "plan-mode",
        "harness": "plan-mode",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "skill-filesystem",
        "harness": "skill-filesystem",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "tool-bash",
        "harness": "tool-bash",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "tool-fs",
        "harness": "tool-fs",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "tool-fs-search",
        "harness": "tool-fs-search",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "tool-goal",
        "harness": "tool-goal",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "tool-jobs",
        "harness": "tool-jobs",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "tool-pwsh",
        "harness": "tool-pwsh",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "tool-skill",
        "harness": "tool-skill",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "tool-subagent",
        "harness": "tool-subagent",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "tool-subagent-control",
        "harness": "tool-subagent-control",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "tool-todo",
        "harness": "tool-todo",
        "note": "Native Harness tool: this is the host it was built for."
      },
      {
        "upstream": "tool-web",
        "harness": "tool-web",
        "note": "Native Harness tool: this is the host it was built for."
      }
    ],
    "emulated": [],
    "missing": []
  },
  "counts": {
    "aliased": 14,
    "emulated": 0,
    "missing": 0,
    "platformTools": 0
  },
  "modes": {
    "schema": "agent-mix-modes/1",
    "upstream": "DSH SuperAgent",
    "modes": [
      "solo",
      "team",
      "research",
      "optimization"
    ],
    "builtinSlugs": [
      "solo",
      "team",
      "research",
      "optimization"
    ],
    "cloudCompatibleSlugs": [
      "solo",
      "team",
      "research",
      "optimization"
    ],
    "groups": [
      "command-goal",
      "plan-mode",
      "skill-filesystem",
      "tool-bash",
      "tool-fs",
      "tool-fs-search",
      "tool-goal",
      "tool-jobs",
      "tool-pwsh",
      "tool-skill",
      "tool-subagent",
      "tool-subagent-control",
      "tool-todo",
      "tool-web"
    ],
    "groupToPermission": {
      "command-goal": "command-goal",
      "plan-mode": "plan-mode",
      "skill-filesystem": "skill-filesystem",
      "tool-bash": "tool-bash",
      "tool-fs": "tool-fs",
      "tool-fs-search": "tool-fs-search",
      "tool-goal": "tool-goal",
      "tool-jobs": "tool-jobs",
      "tool-pwsh": "tool-pwsh",
      "tool-skill": "tool-skill",
      "tool-subagent": "tool-subagent",
      "tool-subagent-control": "tool-subagent-control",
      "tool-todo": "tool-todo",
      "tool-web": "tool-web"
    },
    "permissions": [
      "command-goal",
      "plan-mode",
      "skill-filesystem",
      "tool-bash",
      "tool-fs",
      "tool-fs-search",
      "tool-goal",
      "tool-jobs",
      "tool-pwsh",
      "tool-skill",
      "tool-subagent",
      "tool-subagent-control",
      "tool-todo",
      "tool-web"
    ],
    "policy": "allowlist",
    "policyStatement": "A preset lists the tool packs it mounts; anything not listed is simply not present in that preset. This is an allowlist expressed as package assembly: not mounted means not available.",
    "presetTools": {
      "solo": [
        "tool-bash",
        "tool-pwsh",
        "tool-fs",
        "tool-fs-search",
        "command-goal",
        "tool-goal",
        "skill-filesystem",
        "tool-skill"
      ],
      "team": [
        "tool-bash",
        "tool-pwsh",
        "tool-fs",
        "tool-fs-search",
        "command-goal",
        "tool-goal",
        "tool-jobs",
        "tool-subagent-control",
        "tool-subagent",
        "skill-filesystem",
        "tool-skill"
      ],
      "research": [
        "tool-bash",
        "tool-pwsh",
        "tool-fs",
        "tool-fs-search",
        "tool-web",
        "command-goal",
        "tool-goal",
        "skill-filesystem",
        "tool-skill"
      ],
      "optimization": [
        "tool-bash",
        "tool-pwsh",
        "tool-fs",
        "tool-fs-search",
        "command-goal",
        "tool-goal",
        "tool-jobs",
        "tool-todo",
        "plan-mode",
        "skill-filesystem",
        "tool-skill"
      ]
    },
    "presetDescriptions": {
      "solo": "One agent that turns a request into a scoped plan, implementation, verification, and delivery.",
      "team": "A lead agent that decomposes work, delegates bounded tasks, reviews evidence, and coordinates delivery.",
      "research": "A research agent that separates claims, sources, uncertainty, counterexamples, and reproducible findings.",
      "optimization": "An experiment agent for quality, performance, or combined optimization with baselines, matched measurements, and rollback evidence."
    },
    "evidence": [
      "presets/*/agent.cordis.yml",
      "presets/*/preset.yml"
    ],
    "notes": [
      "bash and pwsh are mutually exclusive by platform (disabled: !!js process.platform ...)",
      "team adds subagent + subagent-control + jobs; research adds web and drops jobs/subagent; optimization adds jobs + todo + plan-mode"
    ],
    "unresolved": [
      "tool argument schemas live in the @deepseek-ai/dsh-tool-* packages, not in this preset package"
    ]
  }
}
