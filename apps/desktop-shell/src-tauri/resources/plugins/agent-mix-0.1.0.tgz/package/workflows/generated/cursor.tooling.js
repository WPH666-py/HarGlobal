export default {
  "schema": "agent-mix-tooling/1",
  "upstream": "Cursor",
  "version": "2.5.25",
  "contractSource": "main.js sha256:",
  "tools": {
    "aliased": [
      {
        "upstream": "glob",
        "harness": "ops_glob"
      },
      {
        "upstream": "list_dir",
        "harness": "ops_glob",
        "note": "List with a single-level glob."
      },
      {
        "upstream": "read_file",
        "harness": "ops_read_files"
      },
      {
        "upstream": "run_terminal_cmd",
        "harness": "pwsh",
        "renames": [
          "is_background->run_in_background"
        ]
      },
      {
        "upstream": "str_replace",
        "harness": "edit",
        "renames": [
          "path->file_path",
          "old_str->old_string",
          "new_str->new_string"
        ]
      },
      {
        "upstream": "terminal",
        "harness": "pwsh"
      },
      {
        "upstream": "todo_write",
        "harness": "todo_write"
      },
      {
        "upstream": "web_fetch",
        "harness": "web_fetch",
        "renames": [
          "prompt->query"
        ]
      },
      {
        "upstream": "web_search",
        "harness": "web_search"
      }
    ],
    "emulated": [
      {
        "upstream": "apply_patch",
        "harness": "edit",
        "note": "Patch-format edits become ordered edit calls;"
      },
      {
        "upstream": "codebase_search",
        "harness": "ops_grep",
        "note": "Harness search is lexical;"
      },
      {
        "upstream": "delete_file",
        "harness": "pwsh",
        "note": "Delete through the shell, deliberately."
      },
      {
        "upstream": "semantic_search",
        "harness": "ops_grep",
        "note": "No embedding index;"
      }
    ],
    "missing": [
      {
        "upstream": "read_lints",
        "note": "No language-server diagnostics tool here."
      }
    ]
  },
  "counts": {
    "aliased": 9,
    "emulated": 4,
    "missing": 1,
    "platformTools": 0
  }
}
