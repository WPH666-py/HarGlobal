export default {
  "schema": "agent-mix-tooling/1",
  "upstream": "OpenCode",
  "version": "1.19.6",
  "contractSource": "apply_patch.ts sha256:51ea2f34f31c8ee2",
  "tools": {
    "aliased": [
      {
        "upstream": "edit",
        "harness": "edit",
        "params": [
          "filePath",
          "oldString",
          "newString",
          "replaceAll"
        ]
      },
      {
        "upstream": "glob",
        "harness": "ops_glob",
        "params": [
          "pattern",
          "path"
        ]
      },
      {
        "upstream": "plan_exit",
        "harness": "exit_plan_mode",
        "params": [
          "path"
        ],
        "renames": [
          "path->plan"
        ]
      },
      {
        "upstream": "question",
        "harness": "ask_user_question",
        "params": [
          "questions"
        ]
      },
      {
        "upstream": "bash",
        "harness": "pwsh",
        "renames": [
          "timeout->timeoutMs"
        ],
        "note": "Registered as bash;"
      },
      {
        "upstream": "skill",
        "harness": "skill",
        "params": [
          "name"
        ]
      },
      {
        "upstream": "task",
        "harness": "subagent"
      },
      {
        "upstream": "todowrite",
        "harness": "todo_write",
        "params": [
          "todos"
        ]
      },
      {
        "upstream": "webfetch",
        "harness": "web_fetch",
        "params": [
          "url",
          "format",
          "timeout"
        ],
        "renames": [
          "prompt->query"
        ]
      },
      {
        "upstream": "websearch",
        "harness": "web_search",
        "params": [
          "query",
          "numResults",
          "livecrawl",
          "type",
          "contextMaxCharacters"
        ]
      }
    ],
    "emulated": [
      {
        "upstream": "apply_patch",
        "harness": "edit",
        "params": [
          "patchText"
        ],
        "note": "Patch-format edits become ordered edit calls;"
      },
      {
        "upstream": "execute",
        "harness": "pwsh",
        "params": [
          "code"
        ],
        "note": "Code-mode execution runs as a shell command, without the typed tool surface."
      },
      {
        "upstream": "grep",
        "params": [
          "pattern",
          "include"
        ],
        "note": "Not mapped;"
      },
      {
        "upstream": "read",
        "params": [
          "filePath",
          "offset",
          "limit"
        ],
        "note": "Not mapped;"
      },
      {
        "upstream": "kilo_local_recall",
        "harness": "knowledge_read",
        "params": [
          "mode",
          "query",
          "sessionID",
          "limit"
        ],
        "note": "Local session recall maps to the knowledge base."
      },
      {
        "upstream": "repo_clone",
        "harness": "pwsh",
        "params": [
          "repository",
          "refresh",
          "branch"
        ],
        "note": "Clone through the shell;"
      },
      {
        "upstream": "write",
        "params": [
          "content",
          "filePath"
        ],
        "note": "Not mapped;"
      }
    ],
    "missing": [
      {
        "upstream": "invalid",
        "note": "Internal placeholder for a malformed tool call."
      },
      {
        "upstream": "lsp",
        "note": "No language-server integration."
      },
      {
        "upstream": "suggest",
        "note": "Inline-completion surface;"
      }
    ]
  },
  "counts": {
    "aliased": 10,
    "emulated": 7,
    "missing": 3,
    "platformTools": 0
  }
}
