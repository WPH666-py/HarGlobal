export default {
  "schema": "agent-mix-tooling/1",
  "upstream": "Claude Code",
  "version": "2.1.326",
  "contractSource": "sdk-tools.d.ts sha256:35fc52c913355aa1",
  "tools": {
    "aliased": [
      {
        "upstream": "Agent",
        "harness": "subagent",
        "params": [
          "description",
          "prompt",
          "subagent_type",
          "model",
          "effort",
          "run_in_background",
          "name",
          "team_name",
          "mode",
          "isolation"
        ],
        "note": "`subagent_type`/`model`/`isolation` have no per-call equivalent."
      },
      {
        "upstream": "Bash",
        "harness": "pwsh",
        "params": [
          "command",
          "timeout",
          "description",
          "run_in_background",
          "dangerouslyDisableSandbox"
        ],
        "renames": [
          "timeout->timeoutMs"
        ]
      },
      {
        "upstream": "ExitPlanMode",
        "harness": "exit_plan_mode",
        "params": [
          "allowedPrompts"
        ]
      },
      {
        "upstream": "FileEdit",
        "harness": "edit",
        "params": [
          "file_path",
          "old_string",
          "new_string",
          "replace_all"
        ]
      },
      {
        "upstream": "FileRead",
        "harness": "ops_read_files",
        "params": [
          "file_path",
          "offset",
          "limit",
          "pages",
          "allow_large"
        ],
        "renames": [
          "file_path->path"
        ],
        "note": "Harness reads by line range;"
      },
      {
        "upstream": "FileWrite",
        "harness": "write",
        "params": [
          "file_path",
          "content"
        ]
      },
      {
        "upstream": "Glob",
        "harness": "ops_glob",
        "params": [
          "pattern",
          "path"
        ]
      },
      {
        "upstream": "Grep",
        "harness": "ops_grep",
        "params": [
          "pattern",
          "path",
          "glob",
          "output_mode",
          "-B",
          "-A",
          "-C",
          "context",
          "-n",
          "-i",
          "-o",
          "type",
          "head_limit",
          "offset",
          "multiline"
        ],
        "renames": [
          "output_mode->outputMode"
        ]
      },
      {
        "upstream": "TaskStop",
        "harness": "job_kill",
        "params": [
          "task_id",
          "shell_id"
        ],
        "renames": [
          "shell_id->job_id",
          "task_id->job_id"
        ]
      },
      {
        "upstream": "ListMcpResources",
        "harness": "list_mcp_resources",
        "params": [
          "server"
        ]
      },
      {
        "upstream": "Mcp",
        "harness": "web_index",
        "note": "Harness routes MCP through per-server tools;"
      },
      {
        "upstream": "ReadMcpResourceDir",
        "harness": "list_mcp_resources",
        "params": [
          "server",
          "uri"
        ]
      },
      {
        "upstream": "ReadMcpResource",
        "harness": "read_mcp_resource",
        "params": [
          "server",
          "uri"
        ]
      },
      {
        "upstream": "TodoWrite",
        "harness": "todo_write",
        "params": [
          "todos"
        ]
      },
      {
        "upstream": "WebFetch",
        "harness": "web_fetch",
        "params": [
          "url",
          "prompt",
          "offset"
        ],
        "renames": [
          "prompt->query"
        ]
      },
      {
        "upstream": "WebSearch",
        "harness": "web_search",
        "params": [
          "query",
          "allowed_domains",
          "blocked_domains"
        ]
      },
      {
        "upstream": "AskUserQuestion",
        "harness": "ask_user_question",
        "params": [
          "answers",
          "annotations",
          "metadata"
        ]
      },
      {
        "upstream": "Workflow",
        "harness": "workflow",
        "params": [
          "script",
          "name",
          "description",
          "title",
          "args",
          "scriptPath",
          "resumeFromRunId"
        ]
      },
      {
        "upstream": "CronDelete",
        "harness": "schedule_delete",
        "params": [
          "id"
        ]
      },
      {
        "upstream": "CronList",
        "harness": "schedule_list"
      },
      {
        "upstream": "ScheduleWakeup",
        "harness": "schedule_create",
        "params": [
          "delaySeconds",
          "reason",
          "prompt",
          "stop",
          "noop"
        ],
        "renames": [
          "delay_seconds->after_seconds"
        ]
      },
      {
        "upstream": "RemoteTrigger",
        "harness": "host_bash",
        "params": [
          "action",
          "trigger_id",
          "session_id",
          "cursor",
          "body"
        ],
        "note": "Remote work is host-scoped in Harness."
      },
      {
        "upstream": "Monitor",
        "harness": "job_output",
        "params": [
          "description",
          "timeout_ms",
          "command",
          "ws"
        ],
        "renames": [
          "shell_id->job_id"
        ]
      },
      {
        "upstream": "ProposeSkills",
        "harness": "skill"
      },
      {
        "upstream": "ProposeGoal",
        "harness": "create_goal",
        "params": [
          "condition",
          "ask_user"
        ]
      },
      {
        "upstream": "Artifact",
        "harness": "artifact_save",
        "params": [
          "file_path",
          "favicon",
          "icon",
          "limit",
          "page_token",
          "scope",
          "title",
          "description",
          "label",
          "url",
          "prompt",
          "force",
          "pin",
          "out_dir",
          "file_paths",
          "asset_id",
          "after",
          "capabilities",
          "contract"
        ]
      }
    ],
    "emulated": [
      {
        "upstream": "RefreshMcpTools",
        "harness": "list_mcp_resources",
        "params": [
          "server"
        ],
        "note": "Harness refreshes tools on its own schedule."
      },
      {
        "upstream": "ReportFindings",
        "harness": "todo_write",
        "params": [
          "level",
          "findings"
        ],
        "note": "No findings channel;"
      },
      {
        "upstream": "EnterPlanMode",
        "harness": "todo_write",
        "note": "Harness plan mode is a session mode, not a tool call."
      },
      {
        "upstream": "TaskCreate",
        "harness": "todo_write",
        "params": [
          "subject",
          "description",
          "activeForm",
          "metadata"
        ],
        "note": "Task board collapses into the todo list."
      },
      {
        "upstream": "TaskGet",
        "harness": "todo_write",
        "params": [
          "taskId"
        ]
      },
      {
        "upstream": "TaskUpdate",
        "harness": "todo_write",
        "params": [
          "taskId",
          "subject",
          "description",
          "activeForm",
          "status",
          "addBlocks",
          "addBlockedBy",
          "owner",
          "metadata"
        ]
      },
      {
        "upstream": "TaskList",
        "harness": "todo_write"
      },
      {
        "upstream": "CronCreate",
        "harness": "schedule_create",
        "params": [
          "cron",
          "prompt",
          "recurring",
          "durable"
        ],
        "note": "Harness schedules are session-local reminders, not OS cron."
      },
      {
        "upstream": "EnterWorktree",
        "harness": "pwsh",
        "params": [
          "name",
          "path"
        ],
        "note": "Emulate with git worktree;"
      },
      {
        "upstream": "ExitWorktree",
        "harness": "pwsh",
        "params": [
          "action",
          "discard_changes"
        ]
      }
    ],
    "missing": [
      {
        "upstream": "NotebookEdit",
        "note": "No notebook-aware editor in Harness;"
      },
      {
        "upstream": "SendFeedback",
        "note": "no native equivalent"
      },
      {
        "upstream": "ClaudeDesign",
        "note": "no native equivalent"
      },
      {
        "upstream": "Projects",
        "note": "no native equivalent"
      },
      {
        "upstream": "ShowOnboardingRolePicker",
        "note": "no native equivalent"
      },
      {
        "upstream": "OfferChromeSetup",
        "note": "no native equivalent"
      },
      {
        "upstream": "ReadNotifications",
        "note": "no native equivalent"
      },
      {
        "upstream": "PushNotification",
        "note": "No out-of-band notification channel."
      }
    ]
  },
  "counts": {
    "aliased": 26,
    "emulated": 10,
    "missing": 8
  }
}
