export default {
  "schema": "agent-mix-tooling/1",
  "upstream": "Kilo Code",
  "version": "7.8.27",
  "contractSource": "apply_patch.ts sha256:51ea2f34f31c8ee2",
  "tools": {
    "aliased": [
      {
        "upstream": "edit",
        "harness": "edit",
        "params": [
          "filePath",
          "oldString",
          "newString",
          "replaceAll"
        ]
      },
      {
        "upstream": "glob",
        "harness": "ops_glob",
        "params": [
          "pattern",
          "path"
        ]
      },
      {
        "upstream": "plan_exit",
        "harness": "exit_plan_mode",
        "params": [
          "path"
        ],
        "renames": [
          "path->plan"
        ]
      },
      {
        "upstream": "question",
        "harness": "ask_user_question",
        "params": [
          "questions"
        ]
      },
      {
        "upstream": "bash",
        "harness": "pwsh",
        "renames": [
          "timeout->timeoutMs"
        ],
        "note": "Registered as bash;"
      },
      {
        "upstream": "skill",
        "harness": "skill",
        "params": [
          "name"
        ]
      },
      {
        "upstream": "task",
        "harness": "subagent"
      },
      {
        "upstream": "todowrite",
        "harness": "todo_write",
        "params": [
          "todos"
        ]
      },
      {
        "upstream": "webfetch",
        "harness": "web_fetch",
        "params": [
          "url",
          "format",
          "timeout"
        ],
        "renames": [
          "prompt->query"
        ]
      },
      {
        "upstream": "websearch",
        "harness": "web_search",
        "params": [
          "query",
          "numResults",
          "livecrawl",
          "type",
          "contextMaxCharacters"
        ]
      },
      {
        "upstream": "agent_manager_models",
        "harness": "list_agents"
      },
      {
        "upstream": "background_process",
        "harness": "pwsh",
        "note": "Track the job with job_output."
      },
      {
        "upstream": "cancel_wakeup",
        "harness": "schedule_delete"
      },
      {
        "upstream": "chart",
        "harness": "viz_figure",
        "params": [
          "title",
          "description",
          "spec"
        ],
        "note": "Render a chart from a declarative spec instead of writing image bytes."
      },
      {
        "upstream": "kilo_memory_recall",
        "harness": "knowledge_read"
      },
      {
        "upstream": "kilo_memory_save",
        "harness": "knowledge_write_node",
        "renames": [
          "content->body"
        ]
      },
      {
        "upstream": "schedule_wakeup",
        "harness": "schedule_create",
        "renames": [
          "delay_seconds->after_seconds"
        ]
      }
    ],
    "emulated": [
      {
        "upstream": "apply_patch",
        "harness": "edit",
        "params": [
          "patchText"
        ],
        "note": "Patch-format edits become ordered edit calls;"
      },
      {
        "upstream": "execute",
        "harness": "pwsh",
        "params": [
          "code"
        ],
        "note": "Code-mode execution runs as a shell command, without the typed tool surface."
      },
      {
        "upstream": "grep",
        "params": [
          "pattern",
          "include"
        ],
        "note": "Not mapped;"
      },
      {
        "upstream": "read",
        "params": [
          "filePath",
          "offset",
          "limit"
        ],
        "note": "Not mapped;"
      },
      {
        "upstream": "kilo_local_recall",
        "harness": "knowledge_read",
        "params": [
          "mode",
          "query",
          "sessionID",
          "limit"
        ],
        "note": "Local session recall maps to the knowledge base."
      },
      {
        "upstream": "repo_clone",
        "harness": "pwsh",
        "params": [
          "repository",
          "refresh",
          "branch"
        ],
        "note": "Clone through the shell;"
      },
      {
        "upstream": "write",
        "params": [
          "content",
          "filePath"
        ],
        "note": "Not mapped;"
      },
      {
        "upstream": "agent_manager",
        "harness": "subagent",
        "note": "Spawning and supervising agents maps to subagents plus list_agents."
      },
      {
        "upstream": "board_read",
        "harness": "todo_write",
        "note": "A kanban board collapses into the todo list."
      },
      {
        "upstream": "cron_create",
        "harness": "schedule_create",
        "note": "Session-scoped reminders, not OS cron."
      },
      {
        "upstream": "link_pr",
        "harness": "pwsh",
        "note": "Drive gh through the shell."
      },
      {
        "upstream": "open_plan",
        "harness": "todo_write",
        "params": [
          "path"
        ],
        "note": "Plans live in the todo list, not in a plan file."
      },
      {
        "upstream": "repo_overview",
        "harness": "pwsh",
        "params": [
          "repository",
          "path",
          "depth"
        ],
        "note": "Summarise with a shell one-liner instead of a dedicated tool."
      },
      {
        "upstream": "semantic_search",
        "harness": "ops_grep",
        "params": [
          "query",
          "path"
        ],
        "note": "Harness search is lexical;"
      }
    ],
    "missing": [
      {
        "upstream": "invalid",
        "note": "Internal placeholder for a malformed tool call."
      },
      {
        "upstream": "lsp",
        "note": "No language-server integration."
      },
      {
        "upstream": "suggest",
        "note": "Inline-completion surface;"
      },
      {
        "upstream": "browser_open",
        "note": "No in-process browser;"
      },
      {
        "upstream": "get_context_info",
        "note": "Harness does not expose a context budget tool."
      },
      {
        "upstream": "generate_image",
        "note": "no native equivalent"
      },
      {
        "upstream": "notebook_read",
        "note": "No notebook-aware reader;"
      },
      {
        "upstream": "notify_user",
        "note": "No out-of-band notification channel."
      },
      {
        "upstream": "send_file",
        "note": "No file delivery channel;"
      }
    ]
  },
  "counts": {
    "aliased": 17,
    "emulated": 14,
    "missing": 9,
    "platformTools": 0
  },
  "modes": {
    "schema": "agent-mix-modes/1",
    "upstream": "Kilo Code",
    "modes": [
      "architect",
      "ask",
      "build",
      "code",
      "debug",
      "orchestrator",
      "plan"
    ],
    "builtinSlugs": [
      "code",
      "build",
      "architect",
      "ask",
      "debug",
      "orchestrator"
    ],
    "cloudCompatibleSlugs": [
      "code",
      "plan",
      "debug",
      "orchestrator",
      "ask",
      "build",
      "architect"
    ],
    "groups": [
      "read",
      "edit",
      "browser",
      "command",
      "mcp"
    ],
    "groupToPermission": {
      "read": "read",
      "edit": "edit",
      "browser": "bash",
      "command": "bash",
      "mcp": "mcp"
    },
    "permissions": [
      "read",
      "edit",
      "bash",
      "mcp"
    ],
    "policy": "whitelist",
    "policyStatement": "A permission that no mode group names is explicitly denied. A mode is a tool-group allowlist over one shared tool set, not a different agent.",
    "evidence": [
      ".extract-work\\kilo\\src\\kilocode-main\\packages\\opencode\\src\\kilocode\\modes-migrator.ts#DEFAULT_MODE_SLUGS",
      ".extract-work\\kilo\\src\\kilocode-main\\packages\\opencode\\src\\kilocode\\modes-migrator.ts#GROUP_TO_PERMISSION",
      ".extract-work\\kilo\\src\\kilocode-main\\packages\\opencode\\src\\kilocode\\modes-migrator.ts#ALL_PERMISSIONS",
      ".extract-work\\kilo\\src\\kilocode-main\\packages\\opencode\\src\\kilocode\\cloud\\defaults.ts#COMPATIBLE"
    ],
    "notes": [
      "source states the rule: a permission not named by a group is explicitly denied (whitelist)"
    ],
    "unresolved": [
      "per-mode group lists are injected at config time (cloud/config-injector), not stored as literals in package source"
    ]
  }
}
