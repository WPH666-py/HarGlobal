export default {
  "schema": "agent-mix-tooling/1",
  "upstream": "Codex",
  "version": "0.169.0",
  "contractSource": "handlers/apply_patch.rs sha256:126ea64fffbcc48e",
  "tools": {
    "aliased": [
      {
        "upstream": "mcp_resource",
        "harness": "read_mcp_resource"
      },
      {
        "upstream": "multi_agents",
        "harness": "subagent"
      },
      {
        "upstream": "multi_agents_v2",
        "harness": "subagent"
      },
      {
        "upstream": "plan",
        "harness": "todo_write"
      },
      {
        "upstream": "request_user_input",
        "harness": "ask_user_question"
      },
      {
        "upstream": "tool_search",
        "harness": "ops_discover_tools"
      },
      {
        "upstream": "unified_exec",
        "harness": "pwsh",
        "renames": [
          "timeout_ms->timeoutMs"
        ],
        "note": "Session-oriented exec;"
      },
      {
        "upstream": "view_image",
        "harness": "read_image",
        "renames": [
          "image_source->file_path"
        ]
      }
    ],
    "emulated": [
      {
        "upstream": "apply_patch",
        "harness": "edit",
        "note": "Patch-format edits become ordered edit calls;"
      },
      {
        "upstream": "curr_time",
        "harness": "pwsh",
        "note": "Get-Date through the shell."
      },
      {
        "upstream": "list_available_plugins_to_install",
        "harness": "pwsh"
      },
      {
        "upstream": "mcp",
        "harness": "list_mcp_resources",
        "note": "MCP calls route through per-server Harness tools."
      },
      {
        "upstream": "new_context_window",
        "harness": "todo_write",
        "note": "Compaction is automatic;"
      },
      {
        "upstream": "request_permissions",
        "harness": "ask_user_question",
        "note": "Harness approval prompts are host-controlled, not tool-callable."
      },
      {
        "upstream": "request_plugin_install",
        "harness": "pwsh",
        "note": "Install through the shell / plugin CLI."
      },
      {
        "upstream": "sleep",
        "harness": "pwsh",
        "note": "Start-Sleep through the shell."
      },
      {
        "upstream": "wait_for_environment",
        "harness": "job_output",
        "note": "Poll a background job instead."
      }
    ],
    "missing": [
      {
        "upstream": "get_context_remaining",
        "note": "Harness does not expose a context budget tool."
      },
      {
        "upstream": "send_message_to_user_async",
        "note": "No out-of-band message channel."
      }
    ]
  },
  "counts": {
    "aliased": 8,
    "emulated": 9,
    "missing": 2,
    "platformTools": 0
  }
}
