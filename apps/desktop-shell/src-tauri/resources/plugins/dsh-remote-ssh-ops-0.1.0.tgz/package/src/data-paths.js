import os from 'node:os'
import path from 'node:path'

export const DATA_DIR_NAME = 'remote-ssh-ops'

// 控制器与 hostd 共用同一目录名，避免后续改名产生两套持久化路径。
export function getDefaultControllerDataDir(homeDir = os.homedir()) {
  // A desktop product exports its own home as DSH_HOME. Two products that both fall back to
  // ~/.dsh would contend for one data directory, and the named-pipe lease would let only the
  // first of them start this plugin.
  const productHome = (process.env.DSH_HOME ?? '').trim()
  if (productHome !== '') return path.join(productHome, DATA_DIR_NAME)
  return path.join(homeDir, '.dsh', DATA_DIR_NAME)
}

export function getDefaultHostdDataDir(homeDir = os.homedir()) {
  return path.join(getDefaultControllerDataDir(homeDir), 'hostd')
}
