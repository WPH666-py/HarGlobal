/**
 * dsh-cursor — import the local Cursor account's model catalog.
 *
 * Activation order:
 *   1. detect a local Cursor installation (nothing at all happens when it is absent)
 *   2. collect the account catalog: live account view -> disk cache -> Cursor's own state
 *   3. write token-free artifacts and, when enabled, merge Claude Code / Codex configuration
 *   4. register the `cursor` route so the imported models appear in the Harness picker
 */
import { collectCatalog } from './lib/catalog.js'
import { resolveConfig } from './lib/config.js'
import { detectCursor } from './lib/detect.js'
import { log } from './lib/log.js'
import { writeArtifacts } from './lib/publish/artifacts.js'
import { clearClientTargets, syncClientTargets } from './lib/publish/clients.js'
import { createCursorAdapter } from './lib/publish/harness.js'
import { createPrintAdapter } from './lib/cli/print-backend.js'
import { createBootstrap, describe } from './lib/cli/bootstrap.js'
import { decode, provision, wslRunAsync } from './lib/cli/provision.js'

export function apply(ctx, rawConfig) {
  if (process.platform !== 'win32') {
    log(ctx, 'info', `dsh-cursor targets Windows only; this host is ${process.platform}, so nothing was imported`)
    return
  }
  const config = resolveConfig(rawConfig)
  registerStatusRoute()
  if (!config.enabled) {
    log(ctx, 'info', 'disabled by configuration')
    return
  }

  let stopped = false
  let disposeRoute = null
  let routeFailed = false
  /** The llm service, once a context that declares it is available. */
  let llmService = null
  let catalog = null
  let signature = ''

  const stopRoute = () => {
    if (!disposeRoute) return
    try {
      disposeRoute()
    } catch {
      /* the route may already be gone */
    }
    disposeRoute = null
  }

  async function refresh(initial) {
    if (stopped) return
    const cursor = detectCursor()
    if (!cursor.installed) {
      clearClientTargets(config, ctx)
      stopRoute()
      if (initial) log(ctx, 'info', 'Cursor is not installed on this machine; nothing imported')
      return
    }

    const next = await collectCatalog({ cursor, config, ctx })
    if (!next || stopped) return

    catalog = next
    const nextSignature = `${next.source}|${next.fetchedAt}|${next.models.length}|${next.models.map((model) => model.id).join(',')}`
    const changed = nextSignature !== signature
    signature = nextSignature

    writeArtifacts({ cursor, catalog: next, config, ctx })
    syncClientTargets({ cursor, catalog: next, config, ctx })
    publishRoute(changed)

    if (initial || changed) {
      log(ctx, 'info', `imported ${next.models.length}/${next.total} Cursor models (${next.source}) as "${config.provider}"`)
    }
  }

  /** Drive Cursor's own CLI; on Windows it lives inside WSL. */
  /**
   * Which address the CLI reaches Cursor from, cached for `egress.refreshSeconds`.
   *
   * The probe is a side path: a machine with no proxy, no WSL or no network reports
   * `{ ok: false, reason }` and every caller keeps working. Nothing here starts or stops WSL.
   * @param force - ignore the cached answer.
   * @returns the egress facts, or why they could not be read.
   */
  async function probeEgress(force = false) {
    const settings = config.egress
    if (!settings.enabled) return { ok: false, reason: 'disabled' }
    const cached = egressCache.value
    if (!force && cached !== undefined && Date.now() - egressCache.at < settings.refreshSeconds * 1000) return cached
    const started = Date.now()
    const seconds = Math.max(1, Math.ceil(settings.timeoutMs / 1000))
    const script = `curl -s --max-time ${seconds} --proxy ${settings.proxy} ${settings.probeUrl}`
    const run = await wslRunAsync([
      'wsl.exe', '-d', config.targets.harness.print.distro, '-u', 'root', '--', 'bash', '-lc', script,
    ], settings.timeoutMs + 8_000)
    const elapsed = Date.now() - started
    let value
    if (!run.ok) {
      value = { ok: false, reason: 'probe-failed', ms: elapsed }
    } else {
      try {
        const facts = JSON.parse(decode(run.stdout).trim())
        const country = typeof facts.country === 'string' ? facts.country.toUpperCase() : ''
        value = {
          ok: true,
          ip: typeof facts.ip === 'string' ? facts.ip : '',
          country,
          org: typeof facts.org === 'string' ? facts.org : '',
          city: typeof facts.city === 'string' ? facts.city : '',
          denied: settings.denied.includes(country),
          proxy: settings.proxy,
          ms: elapsed,
        }
      } catch {
        value = { ok: false, reason: 'probe-unparsable', ms: elapsed }
      }
    }
    egressCache = { at: Date.now(), value }
    return value
  }
  /** Read-only readiness of the CLI the print backend drives, for the settings card. */
  function registerStatusRoute() {
    ctx.inject(['webServer'], (web) => {
      web.effect(() => web.webServer.register({
        kind: 'exact',
        path: '/dsh-cursor/status',
        handler: async (request, response) => {
          if (request.method !== 'GET' && request.method !== 'HEAD') {
            response.writeHead(405, { allow: 'GET, HEAD' }).end()
            return
          }
          const print = config.targets.harness.print
          const result = await createBootstrap({ distro: print.distro, binary: print.binary }).probe()
          const egress = await probeEgress()
          const body = JSON.stringify({ ok: result.ok, distro: result.distro, binary: result.binary, steps: result.steps, egress })
          response.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' })
          response.end(request.method === 'HEAD' ? undefined : body)
        },
      }), 'dsh-cursor: status route')
    })
  }
  /** Drive Cursor's own CLI; on Windows it lives inside WSL. */
  function printAdapter() {
    const print = config.targets.harness.print
    maybeProvision(print.distro)
    return createPrintAdapter({
      provider: config.provider,
      displayName: config.displayName,
      getModels: () => catalog?.models ?? [],
      spawn: { distro: print.distro, workspace: print.workspace, binary: print.binary },
      // Only runs when a turn produces nothing, so a broken setup explains itself.
      diagnose: async () => describe(await createBootstrap({ distro: print.distro, binary: print.binary }).probe()),
    })
  }

  let egressCache = { at: 0, value: undefined }

  let provisioning = null

  /** First use on a machine without a distro: import one in the background. */
  function maybeProvision(distro) {
    if (!config.targets.harness.print.autoProvision || provisioning) return
    provisioning = provision({
      distro,
      run: wslRunAsync,
      log: (message) => log(ctx, 'info', `provision: ${message}`),
    })
      .then((result) => log(ctx, 'info', `provision: ${result.status} (${result.distro})`))
      .catch((error) => log(ctx, 'warn', `provision failed: ${error?.message ?? error}`))
      .finally(() => { provisioning = null })
  }

  function publishRoute(changed) {
    if (!config.targets.harness.enabled) {
      stopRoute()
      return
    }
    if (routeFailed) return
    if (llmService === null) return
    if (typeof llmService.registerAdapter !== 'function') {
      routeFailed = true
      log(ctx, 'warn', 'this host has no llm service; the model list was exported but not registered')
      return
    }
    if (disposeRoute) {
      if (!changed) return
      try {
        disposeRoute.replace([config.provider])
        return
      } catch {
        disposeRoute = null
      }
    }
    try {
      const adapter = config.targets.harness.backend === 'print'
        ? printAdapter()
        : createCursorAdapter({ getCatalog: () => catalog, config, llm: llmService })
      disposeRoute = llmService.registerAdapter([config.provider], adapter)
    } catch (error) {
      routeFailed = true
      log(ctx, 'warn', `could not register the "${config.provider}" route: ${error?.message ?? error}`)
    }
  }

  // Cordis rejects a direct `ctx.llm` read from a plugin that never declared the dependency,
  // and that throw used to be swallowed by the refresh catch: the catalog exported but the
  // route never registered, so the picker stayed empty. Resolve it through an injected child
  // context, which also retries once the service appears.
  ctx.inject(['llm'], (scoped) => {
    llmService = scoped.llm
    publishRoute(true)
    return () => {
      llmService = null
      stopRoute()
    }
  })

  ctx.effect(() => {
    let timer = null
    const run = (initial) => {
      refresh(initial).catch((error) => log(ctx, 'warn', `import failed: ${error?.message ?? error}`))
    }
    run(true)
    timer = setInterval(() => run(false), config.refreshSeconds * 1000)
    if (typeof timer.unref === 'function') timer.unref()
    return () => {
      stopped = true
      if (timer) clearInterval(timer)
      stopRoute()
    }
  })
}